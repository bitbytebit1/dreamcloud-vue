<template>
  <v-flex xs12>
    <v-container fill-height>
      <v-layout align-center>
        <v-flex>
          <loading></loading>
          <h1 class="display-2 fwl">{{error}}</h1>
          <div class="subheading my-2 text-xs-center">{{title}}</div>
          <v-divider class="my-3"></v-divider>
          <div class="title mb-3 text-xs-center">{{subheading}}</div>
          <v-btn color="primary white--text" v-if="discover" :to="{name: 'explore'}" >discover new music<v-icon right>explore</v-icon></v-btn> 
        </v-flex>
      </v-layout>
    </v-container>
</v-flex>
</template>

<script>
import loading from '@/components/misc/orbit'
export default {
  name: 'jumbo',
  components: {
   'loading': loading 
  },
  props: {
    subheading: String,
    title: String,
    discover: {
      type: Boolean,
      default: true
    },
    error: {
      type: String,
      default: 'oops'
    }
  }
}
</script>

