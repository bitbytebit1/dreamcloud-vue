<template>
  <span style="display:inline-block" :class="{w100: inList}">
    <!-- LIST -->
    <v-list-tile v-if="inList" ripple @click.stop="openMenu" class="w100">
      <v-list-tile-title>Add to playlist</v-list-tile-title>
      <v-list-tile-action>
        <v-btn :disabled="disabled" :color='btnCol' icon>
          <v-icon>playlist_add</v-icon>
        </v-btn>    
      </v-list-tile-action>
    </v-list-tile>

    <!-- BUTTON ONLY -->
    <v-tooltip top v-else >
      <v-btn slot="activator" class="ml-2" :disabled="disabled" :color='btnCol' icon @click.stop="openMenu" >
        <v-icon>playlist_add</v-icon>
      </v-btn>
      <span>Add to playist</span>
    </v-tooltip>

    <!-- DIALOG -->
    <v-dialog dark v-model="menuOpen" max-width="500px">
      <!-- height="385" -->
      <v-card flat :height="cardHeight1">
        <v-card-text class="title fwl ma-0 pa-2">
          Add to playlist
        </v-card-text>
        <v-card-actions>
          <v-autocomplete
            v-on:keyup.enter='enter'
            v-model="select"
            :menu-props="`{ maxHeight: '${cardHeight2}', contentClass: 'noShadow pt-1'}`"
            class="ma-0"
            :items="items"
            :search-input.sync="search"
            @click:append="enter"
            item-value="key"
            item-text="name"
            append-icon="add"
            no-data-text="Create new playlist"
            label="Name"
            color="primary"
            ref="auto"
            return-object
            single-line
            hide-no-data
          >
            <template slot="item" slot-scope="data">
              <v-list-tile-content @click="clicked(data.item)" v-text="data.item.name"></v-list-tile-content>
            </template>
          </v-autocomplete>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </span>
</template>
<script>
// /* eslint-disable */
export default {
  name: 'add-to-playlist',
  props: {
    song: [Array, Object],
    disabled: Boolean,
    inList: Boolean
  },
  data () {
    return {
      items: [],
      btnCol: '',
      menuOpen: false,
      loading: false,
      search: null,
      select: ''
    }
  },
  computed: {
    cardHeight1 () {
      return this.$vuetify.breakpoint.xsOnly ? '277' : '385'
    },
    cardHeight2 () {
      return this.$vuetify.breakpoint.xsOnly ? '190' : '300'
    }
  },
  methods: {
    clicked (v) {
      this.emit(v)
    },
    enter () {
      this.emit(this.select)
    },
    emit (v) {
      if (typeof v === 'object') {
        this.$DCFB.playlistSongAdd(v['.key'], this.song)
      } else {
        this.$DCFB.createNewPlaylist(this.search, this.song)
      }
      this.btnFeedback()
    },
    openMenu () {
      this.menuOpen = !this.menuOpen
      // this.$emit('opened', true)
      setTimeout(() => {
        // VTFY CLASS
        this.$refs.auto.$el.querySelector('.v-select__slot').click()
        this.$refs.auto.$el.querySelector('input').focus()
      }, 600)
    },
    btnFeedback () {
      //  this.menuOpen = this.$UTILS.isMobile ? false : true
      this.playlistName = ''
      this.btnCol = 'green'
      setTimeout(() => {
        this.menuOpen = false
        this.$emit('opened', false)
        this.btnCol = ''
      }, 420)
    },
    bind () {
      if (this.artistID && this.$store.getters.auth_state) {
        this.$bindAsArray('subscribed', this.$DCFB.subscriptions.child(this.artistID))
      }
    }
  },
  created () {
    if (this.$store.getters.auth_state) {
      this.$bindAsArray('items', this.$DCFB.playlists.orderByChild('name_lower'))
    }
  }
}
</script>

<style>
.w100{
  width: 100%;
}
.noShadow{
  box-shadow: none !important;
}
</style>
