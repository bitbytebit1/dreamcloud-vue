<template>
  <div class="mb-1">
    <v-list dense class="pa-0">

      <!-- Change to for loop to save the whales... I mean internet -->

      <!-- RECOMMENDED -->
      <v-list-tile 
        ripple 
        @click="closeLeft" 
        :to="{name: 'historyRecommended', params: {user: UID}}"
        active-class="primary white--text"
      >
        <v-list-tile-action>
          <v-icon>home</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>Home</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>

      <!-- trending -->
      <v-list-tile 
        ripple 
        @click="closeLeft" 
        :to="{name: 'trending'}"
        active-class="primary white--text"
      >
        <v-list-tile-action>
          <v-icon>whatshot</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>Trending</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>

      <!-- CURRENTLY PLAYING
      <v-list-tile 
        ripple 
        @click="closeLeft" 
        :to="{name: 'stage'}"
        active-class="primary white--text"
      >
        <v-list-tile-action>
          <v-icon>music_video</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>Current</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile> -->

      <v-list-tile active-class="primary white--text" ripple @click="closeLeft" :to="{name: 'explore'}">
        <v-list-tile-action>
          <v-icon>public</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>Explore</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>


      <!-- Subscriptions all -->
      <v-list-tile active-class="primary white--text" ripple @click="closeLeft" :to="{name:'subsAll', params: {user: UID}}">
        <v-list-tile-action>
          <v-icon>people</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>Subscriptions</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>

      <!-- history -->
      <v-list-tile ripple active-class="primary white--text" class="history-link" @click="closeLeft" :to="{name:'history', params: {user: UID}}">
        <v-list-tile-action>
          <v-icon>history</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>History</v-list-tile-title>
        </v-list-tile-content>
        <span class="delete">
          <delete-button @delete="clearHistory"></delete-button>
        </span>
      </v-list-tile>

      <!-- about -->
      <!-- <v-list-tile v-if="!loggedIn" active-class="primary white--text" ripple @click="closeLeft" :to="{name: 'about'}">
        <v-list-tile-action>
          <v-icon>info</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>About</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile> -->

      <!-- login -->
      <!-- <v-list-tile v-if="!loggedIn" active-class="primary white--text" ripple @click="closeLeft" :to="{path: '/login'}">
        <v-list-tile-action>
          <v-icon>person</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>Login</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>
       -->
      <!-- settings -->
      <v-list-tile ripple @click="closeLeft" active-class="primary white--text" :to="{path: '/settings'}">
        <v-list-tile-action>
          <v-icon>settings</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>Settings</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>
    </v-list>
    
    <!-- Playists -->
    <v-list dense class="pa-0">
      <user-playlists @closeLeft="closeLeft"></user-playlists>
    </v-list>
    
    <!-- Subscriptions -->
    <v-list dense class="pa-0">
      <user-subscriptions @closeLeft="closeLeft"></user-subscriptions>
    </v-list>

    <!-- tos -->
    <!-- <v-list dense class="pa-0 mb-5">
      <v-list-tile ripple @click="closeLeft" :to="{path: '/tos'}">
        <v-list-tile-action>
          <v-icon>forum</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>Terms of Use</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>
    </v-list> -->
  </div>
</template>
<script>
import userPlaylists from '@/components/sidebar-left/user-playlists/user-playlists'
import userSubscriptions from '@/components/sidebar-left/user-subscriptions/user-subscriptions'
import deleteButton from '@/components/buttons/delete-button'
export default {
  name: 'sidebar',
  components: {
    'user-playlists': userPlaylists,
    'user-subscriptions': userSubscriptions,
    'delete-button': deleteButton
  },
  data () {
    return {
      userDrawer: false
    }
  },
  methods: {
    closeLeft () {
      this.$emit('closeLeft', 'left')
    },
    clearHistory () {
      this.$DCFB.historyClear()
    }
  },
  computed: {
    UID () {
      return this.$store.getters.uid
    },
    loginPath () {
      return '/' + this.loginText.toLowerCase()
    },
    loginText () {
      return this.loggedIn ? 'User' : 'Login'
    },
    loggedIn () {
      return this.$store.getters.auth_state
    }
  },
  mounted () {

  }
}
</script>

<style>
.ar17{
  position:absolute !important;
  right:1px;
}
.list__tile--active .delete, .history-link:hover .delete {
  display: inherit!important
}
</style>
