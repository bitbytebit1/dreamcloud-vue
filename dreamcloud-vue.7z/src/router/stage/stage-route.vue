<template>
  <div></div>
</template>
<script>
export default {
  name: 'stage-route',
  created () {
    this.$store.commit('bShowStage', true)
  }
}
</script>

<style>
</style>
