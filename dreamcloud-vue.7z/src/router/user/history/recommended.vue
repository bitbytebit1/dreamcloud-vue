<template>
  <v-flex xs12 :lg10="viewSmall" :lg12="!viewSmall">
    <div v-if="bLoading || aRecommended.length" class="headline fwl text-xs-left pl-2 pt-2">Home</div>
    <!-- <loading v-if="!auth_state || !aRecommended.length"></loading> -->
    <playlist v-if="bLoading || aRecommended.length" :rowsPerPage='rowsPerPage' :showUploaded="true" :songs="aRecommended2"></playlist>
    <!-- title="Here is supposed to be a playlists generated from your recent history" -->
    <jumbo
      v-else-if="bFailed"
      title="We wanted to recommend you some music based on your history"
      subheading="But you haven't listened to any music yet"
    ></jumbo>
  </v-flex>
</template>
<script>
import axios from 'axios'
/* eslint-disable */
import jumbo from '@/components/misc/jumbo'
import deleteButton from '@/components/buttons/delete-button'
import { mapGetters } from 'vuex'
export default {
  name: 'recommended',
  components: {
    'jumbo': jumbo
  },
  props: {
    iLimit: {
      type: [Number],
      default: 100
    },
    rowsPerPage: {
      type: [Number],
      default: 100
    }
  },
  data () {
    return {
      bLoading: false,
      bFailed: false,
      iLoaded: 1,
      aRecommended: [],
      bLoaded: false,
      viewSmall: this.$route.name === 'historyRecommended'
    }
  },
  watch: {
    'auth_state': {
      immediate: true,
      handler: 'bind'
    },
  },
  methods: {
    bind () {
      if (this.auth_state) {
        this.bFailed = false
        this.$store.commit('loadActive', true)
        this.$bindAsArray('aHistory', this.$DCFB.history.limitToLast(this.iLimit), null, this.getRecommended)
      }
    },
    getRecommended () {
      if (!this.aHistory.length) {
        this.$store.commit('loadActive', false)
        this.bLoading = false
        this.bFailed = !this.aHistory.length
        return
      }
      this.bLoading = true
      // promise array
      var aAjax = []
      // reverse firebase array
      var aRecommended = this.aHistory.reverse()
      // strip out duplicates
      aRecommended = this.$UTILS.uniqueArray(aRecommended)
      // reset counter
      this.iLoaded = 1

      // loop through history array
      for (var i = 0; i < aRecommended.length - 1; i++) {
        // get 2 recommended songs for each item in history
        aAjax.push(this.$DCAPI.searchInt('', 0, [aRecommended[i].source], aRecommended[i].trackID, (d) => {
          this.iLoaded++
          if (d.length) {
            this.aRecommended.push(d[0])
            this.aRecommended.push(d[1])
          }

          this.$store.commit('loadValue',  (100 / aRecommended.length) * this.iLoaded)

        }, true, 2))
      }
      axios.all(aAjax).then(() => {
        this.aRecommended = this.$UTILS.uniqueArray(this.aRecommended)
        this.bLoading = false
        setTimeout(() => {
          this.$store.commit('loadActive', false)
        }, 200)
      })
    }
  },
  computed: {
    ...mapGetters({auth_state: 'auth_state'}),
    aRecommended2 () {
      return this.bLoading ? [] : this.aRecommended
    }
  },
  destroyed () {
    this.$store.commit('loadActive', false)
  }
}
</script>

<style>
</style>
