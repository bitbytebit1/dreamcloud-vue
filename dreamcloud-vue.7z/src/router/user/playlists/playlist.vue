<template>
  <v-flex xs12 lg10 flexbox>
    <div class="headline fwl text-xs-left pl-2 pt-2">{{name}}</div>
    <playlist :showUploaded="true" :songs="aSongs" rowsPerPage='250'></playlist>
  </v-flex>
</template>
<script>
import loading from '@/components/misc/loading'

export default {
  name: 'userPlaylist',
  props: ['user', 'playlist', 'name'],
  watch: {
    '$route.params': {
      immediate: true,
      handler: 'bind'
    }
  },
  components: {
    'loading': loading
  },
  data () {
    return {
      aSongs: []
    }
  },
  methods: {
    bind () {
      this.$store.dispatch('loadIndeterm', true)
      this.$bindAsArray('aSongs', this.$DCFB.playlistGet(this.$route.params.user, this.$route.params.playlist), null, () => {
        this.$store.dispatch('loadIndeterm', false)
      })
    }
  }
}
</script>
