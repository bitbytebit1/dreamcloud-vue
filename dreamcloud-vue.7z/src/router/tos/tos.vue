<template>
    <div class="text-xs-left">
      <v-flex
       xs14 
       lg10
       offset-lg1
      >
        <v-card>
          <v-card-title
            class="primary"
            primary-title
          >
            Terms Of Service
          </v-card-title>
  
         <v-card-text class="preline">{{ x1 }}</v-card-text>
         
         <!-- Add so it does something on click
          <v-divider></v-divider>
          <v-card-actions>
            <v-spacer></v-spacer>

            <v-btn
              color="primary"
              flat
            >
              I decline
            </v-btn>
           
            <v-btn
              color="primary"
              flat
            >
              I accept
            </v-btn>
          </v-card-actions>
          -->
        </v-card>
        </v-flex>
      </div>
</template>
<script>
/* eslint-disable */
export default {
  name: 'tos',
  data () {
    return {
      x1: 
`dreamcloud.netlify.com Terms of Service Agreement. Welcome to dreamcloud.netlify.com. By using (the "Service") dreamcloud.netlify.com (the "Web site") you agree to be bound by these Terms of Use Agreement (this "Agreement"):

This Agreement sets out the legally binding terms of your use of the Web site and the Service and may be modified by dreamcloud.netlify.com at any time and without prior notice, such modifications to be effective upon posting by dreamcloud.netlify.com site. This Agreement includes dreamcloud.netlify.com acceptable use policy for Content (the "Content") posted or accessed trough the Web site, dreamcloud.netlify.com Privacy Policy, and any notices regarding the Web site.

ELIGIBILITY

By using the Web site, you represent and warrant that you have the right, authority, and capacity to enter into this Agreement and to abide by all of the terms and conditions of this Agreement.

TERM

This Agreement will remain in full force and effect while you use the Web site.

NON COMMERCIAL USE BY MEMBERS

dreamcloud.netlify.com is intended for the personal use, unauthorized framing of or linking to the Web site will be investigated, and appropriate legal action will be taken, including without limitation, civil, criminal, and injunctive redress.

COPYRIGHT POLICY

None of information, code, data, text, software, music, sound, photos, pictures, graphics, video, chat, messages, files, or other materials (the "Content") that can be accessed by using this site are hosted by this site; this site is not affiliate with the pages that you access. You only can use this site to examine your own pages, you acknowledge, warrant and represent that you legally own all intellectual property rights of the content that you access using this service. You may not post, distribute, or reproduce in any way any copyrighted material, trademarks, or other proprietary information without obtaining the prior written consent of the owner of such proprietary rights. You are solely responsible for the content that you access using this service.

dreamcloud.netlify.com Privacy and Cookie Policy
Privacy Policy

Your privacy is important to us. To better protect your privacy we provide this notice explaining our online information practices and the choices you can make about the way your information is collected and used. To make this notice easy to find, we make it available on our homepage and at every point where personally identifiable information may be requested.

Please read the following carefully. If you have any questions or concerns, please send us an email at dreamcloud@sharklasers.com.

Gathering and Use of Information

Dreamcloud will never willfully disclose any personally identifiable information about our online audience to any third party without first receiving the user's permission. We do not collect personally identifiable information from our visitors other than what is supplied to us on a voluntary basis.

Visitors to the Dreamcloud Web Site may voluntarily supply certain personally identifiable information in connection with (i)contest or sweepstakes registration, (ii) subscription registration for sites or services which require subscription (such as email newsletters), (iii) requests for membership information and (iv) e-commerce transactions. In addition, personally identifiable information is voluntarily provided in connection with certain content submissions, community postings (i.e., forums or bulletin boards), comments and suggestions, or voting.

Some of our sites contain links to other sites whose information practices may be different than ours. Visitors should consult the other sites' privacy notices as we have no control over information that is submitted to, or collected by, these third parties.

Dreamcloud may use such information only for conducting the activities stated above, for internal marketing and promotional purposes, or, on occasion, when mailing lists are made available to other organizations. (The occasional provision of mailing lists to such organizations is the only case where such information would be provided to third parties).

If the visitor does not want this information collected and used by us for the disclosed internal purposes, the visitor is given an opportunity to 'opt-out.' Our visitors need to recognize, however, that under certain circumstances, if they select to 'opt-out' they may not be eligible for certain activities for which the personally identifiable information is needed. (For example, if a contest participant elects to 'opt-out' on permitting us to collect and use their personal information, we cannot contact them if they win without using such information.)

Cookies

We use a number of different cookies on our site. If you do not know what cookies are, or how to control or delete them, then we recommend you visit http://www.aboutcookies.org for detailed guidance.

Below we describe the cookies we use on this site and what we use them for. Currently we operate an ‘implied consent’ policy which means that we assume you are happy with this usage. If you are not happy, then you should either not use this site, or you should delete Dreamcloud cookies having visited the site, or you should browse the site using your browser’s anonymous usage setting (called “Incognito” in Chrome, “InPrivate” for Internet Explorer, "Private Browsing" in Firefox and Safari etc.)

"Session" Cookies

We use a session cookie to remember your activity. These we deem strictly necessary to the working of the website. If these are disabled then various functionality on the site will be broken. More information on session cookies and what they are used for at http://www.allaboutcookies.org/cookies/session-cookies-used-for.html

Persistent Cookies for Site Analytics and Performance

We use some persistent cookies to enhance the relevancy of information displayed on the site. User data is anonymous. More information about persistent cookies and what they are used for at http://www.allaboutcookies.org/cookies/persistent-cookies-used-for.html

Google AdSense – this cookie is used by Google to report to us how the adverts shown on dreamcloud.netlify.com are performing. User data is all anonymous. You can find out more generally about Google and its policies and principles as regards advertising at http://www.google.com/policies/privacy/ads/

Google Analytics – we use this to understand how the site is being used in order to improve the user experience. User data is all anonymous. You can find out more about Google’s position on privacy as regards its analytics service at http://www.google.co.uk/intl/en/analytics/privacyoverview.html

Social buttons. On many of the pages of the site you will see ‘social buttons’. These enable users to share or bookmark the web pages. There are buttons for: Twitter, Google +1, Facebook ‘Like’. In order to implement these buttons, and connect them to the relevant social networks and external sites, there are scripts from domains outside of Dreamcloud. You should be aware that these sites are likely to be collecting information about what you are doing all around the internet, including on Dreamcloud’s site. So if you click on any of these buttons, these sites will be registering that action and may use that information. In some cases these sites will be registering the fact that you are visiting Dreamcloud, and the specific pages you are on, even if you don’t click on the button if you are logged into their services, like Google and Facebook. You should check the respective policies of each of these sites to see how exactly they use your information and to find out how to opt out, or delete, such information.

Email tracking. Emails we send we put in tracking so that we can tell how much traffic those emails send to our site but we do not know who has clicked so the data is anonymous e.g. our daily newsletter. Some emails we can track, at an individual level, whether the user has opened and clicked on the email. We rarely use the latter information at a personal level, rather we use it to understand open and click rates on our emails to try and improve them. Sometimes we do use the personal information e.g. to re-email people who didn’t click the first time. If you want to be sure that none of your email activity is tracked then you should opt out of Dreamcloud’s emails.

Acceptance of these Dreamcloud Web Site Privacy Policy Terms and Conditions

By using this site, you signify your agreement to the terms and conditions of this Dreamcloud Web Site Privacy Policy. If you do not agree to these terms and conditions, please do not use the site. We reserve the right, at our sole discretion, to change, modify, add, or remove portions of this policy at any time.

From time to time, Dreamcloud may update this privacy notice. We will notify you about material changes in the way we treat personally identifiable information by placing a notice on our site. We encourage you to periodically check back and review this policy so that you always will know what information we collect, how we use it, and to whom we disclose it. Your continued use of the Dreamcloud Web Site following the posting of any changes to these terms shall mean that you have accepted those changes.

Should you have other questions or concerns about these privacy policies, please email us at dreamcloud@sharklasers.com.

DISCLAIMERS

dreamcloud.netlify.com is not responsible for any incorrect or inaccurate Content posted on the Web site or in connection with the Service, whether caused by any of the equipment or programming associated with or utilized in the Service. dreamcloud.netlify.com assumes no responsibility for any error, omission, interruption, deletion, defect, delay in operation or transmission, communications line failure, theft or destruction or unauthorized access to, or alteration of, user or communications. dreamcloud.netlify.com is not responsible for any problems or technical malfunction of any telephone network or lines, computer online systems, servers or providers, computer equipment, software, failure of email or players on account of technical problems or traffic congestion on the Internet or at any web site or combination thereof, including injury or damage to users or to any other person's computer related to or resulting from participating or downloading materials in connection with the Web and/or in connection with the Service. Under no circumstances will dreamcloud.netlify.com be responsible for any loss or damage, including personal injury or death, resulting from anyone's use of the Web site or the Service, any Content posted on the Web site, accessed trough the site. The Web site and the Service are provided "AS-IS" and dreamcloud.netlify.com expressly disclaims any warranty of fitness for a particular purpose or non-infringement. dreamcloud.netlify.com cannot guarantee and does not promise any specific results from use of the Web site and/or the Service. The service may be temporarily unavailable from time to time for maintenance or other reasons.

LIMITATION ON LIABILITY

In no event will dreamcloud.netlify.com be liable to you or any third person for any indirect, consequential, exemplary, incidental, special or punitive damages, including also lost profits arising from your use of the Web site or the Service, even if dreamcloud.netlify.com has been advised of the possibility of such damages.

INDEMNITY

You agree to indemnify and hold dreamcloud.netlify.com, its subsidiaries, affiliates, officers, agents, and other partners and employees, harmless from any loss, liability, claim, or demand, including reasonable attorney's fees, made by any third party due to or arising out of your use of the Service in violation of this Agreement and/or arising from a breach of this Agreement and/or any breach of your representations and warranties set forth above.

NO AGENCY

There is no agency, partnership, joint venture, employee-employer or franchisor-franchisee relationship between dreamcloud.netlify.com and any User of the Service.

OTHER

This Agreement, accepted upon use of the Web site, contains the entire agreement between you and dreamcloud.netlify.com regarding the use of the Web site and/or the Service. The failure of dreamcloud.netlify.com to exercise or enforce any right or provision of these Terms of Service shall not constitute a waiver of such right or provision. If any provision of this Agreement is held invalid, the remainder of this Agreement shall continue in full force and effect. The section titles in these Terms of Service are for convenience only and have no legal or contractual effect.

I HAVE READ THIS AGREEMENT AND AGREE TO ALL OF THE PROVISIONS CONTAINED ABOVE.`
    }
  },
  methods: {
    x2 () {

    }
  },
  computed: {
    x3 () {
      
    }
  }
}
</script>

<style>
</style>
