<template>
  <v-flex xs12 lg10>
    <div class="loading" v-if="loading">
      Loading...
    </div>
    <playlist :songs="searchResults"></playlist>
  </v-flex>
</template>

<script>

export default {
  name: 'searchpage',
  props: ['source', 'artist', 'trackID'],
  data () {
    return {
      loading: false,
      searchResults: []
    }
  },
  watch: {
    '$route.params': {
      immediate: true,
      handler: 'search'
    }
  },
  methods: {
    search () {
      this.loading = true
      this.searchResults = []
      this.$DCAPI.getSongInfo(this.$route.params.trackID, this.$route.params.source, (d) => {
        this.loading = false
        this.searchResults.push(...d)
      }, '')
    }
  }
}
</script>
