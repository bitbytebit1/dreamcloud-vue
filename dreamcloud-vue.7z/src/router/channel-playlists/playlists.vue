<template>
  <v-flex xs12 lg12>
    <v-card>
      <v-card-title class="ma-0 pa-0">
        <v-flex xs12 >
          <!-- filter -->
          <v-text-field
            @focus="filterHasFocus = true"
            @blur="filterHasFocus = false"
            v-on:keyup.enter="$UTILS.closeSoftMobi()"
            v-model="search"
            color="primary"
            id="flr-txt"
            label="Filter"
            ref="search"
            class="mr-4 ml-4 mb-3"
            clearable
            single-line
            hide-details
          ></v-text-field>
        </v-flex>
      </v-card-title>
      <v-container grid-list-lg class="pa-0" fluid>
        <v-data-iterator
          content-tag="v-layout"
          row
          wrap
          class=""
          :items="aPlaylist"
          :search="search"
          :rows-per-page-items="rowsPerPageItems"
          :custom-filter="(items, search, filter) => { search = search.toString().toLowerCase() ; return items.filter(row => filter(row['title'], search)) }"
          pagination.sync="pagination"
          hide-actions
        >
          <v-flex
            slot="item"
            slot-scope="props"
            xs12
            sm6
            md4
            lg3
            v-if="props.item.numberOfSongs"
          >
            <!-- {{props.item['.key']}} -->
            <!-- {{props.item.name_lower}} -->
            <!-- {{props.item.songs[Object.keys(props.item.songs)[0]].poster}} -->
            <!-- Object.keys(aPlaylist[props.index].songs)[0] -->
            <v-card class="pointer dc-crd" :to="{name: 'channelPlaylist', params: {listID: props.item.listID, artistID: props.item.artistID, title: props.item.title, source: props.item.source}}" >
              <v-img
                :aspect-ratio="props.item.source === 'YouTube' ? 16/9 : '1'"
                :src="props.item.img"
                :lazy-src="props.item.img"
              >
                <v-layout
                  slot="placeholder"
                  fill-height
                  align-center
                  justify-center
                  ma-0
                >
                  <!-- <span class="songLeng">{{props.item.numberOfSongs}}</span> -->
                </v-layout>
              </v-img>
              <v-card-text class="text-xs-center subheading">{{ props.item.title }}</v-card-text>
            </v-card>
          </v-flex>
        </v-data-iterator>
      </v-container>
    </v-card>
  </v-flex>
</template>
<script>
// /* eslint-disable */
// import deleteButton from '@/components/buttons/delete-button'
export default {
  name: 'playlistOverview',
  props: ['aPlaylist'],
  data () {
    return {
      filterHasFocus: false,
      search: '',
      active: true,
      rowsPerPageItems: [{ text: 'All', value: -1 }],
      pagination: {
        rowsPerPage: 'All'
      }
    }
  },
  created () {
    // this.bind()
  }
}
</script>

<style>
.songLeng{
  color: white;
  text-shadow: 0px 0px 5px black;
  background: rgba(1, 1, 1, .5);
  position: absolute;
  bottom: 0px;
  right: 0px;
}
</style>
