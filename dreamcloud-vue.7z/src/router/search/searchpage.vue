<template>
  <v-flex xs12 lg10 flexbox>
    <!-- <loading v-if="loading"></loading> -->
    <playlist :showUploaded="!0" v-if="!loading" rowsPerPage='50' :songs="searchResults"></playlist>  
    <infinite-loading :distance="210" ref="infiniteLoading" v-if="!loading" @infinite="infiniteHandler" spinner="waveDots">    
      <span slot="no-more"></span>
    </infinite-loading>
  </v-flex>
</template>

<script>
import InfiniteLoading from 'vue-infinite-loading'
import loading from '@/components/misc/loading'

export default {
  name: 'searchpage',
  props: ['query', 'source'],
  data () {
    return {
      loading: false,
      searchResults: [],
      iPage: 0
    }
  },
  components: {
    'infinite-loading': InfiniteLoading,
    'loading': loading
  },
  computed: {
    splitSource () {
      return this.source.split('-')
    }
  },
  watch: {
    '$route.params': {
      immediate: true,
      handler: 'searchInt'
    }
  },
  methods: {
    infiniteHandler ($state) {
      this.search(++this.iPage).then(function () {
        $state.loaded()
      })
    },
    searchInt () {
      this.$store.dispatch('loadIndeterm', true)
      this.search(0)
    },
    search (iPage) {

      this.searchResults = !iPage ? [] : this.searchResults

      return this.$DCAPI.searchInt(this.$route.params.query, iPage, this.splitSource, '', (d) => {
        this.loading = false
        if (iPage === 0) {
          this.$store.dispatch('loadIndeterm', false)
        }
        // If no results stop infinite loading
        if (!d.length) {
          this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
        }
        this.searchResults.push(...d)
      }, '')
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>

</style>
