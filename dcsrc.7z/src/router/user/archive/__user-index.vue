    },
    search (sUser) {
      sUser = sUser || this.user
