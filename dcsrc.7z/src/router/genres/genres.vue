<template>
  <v-flex 
    :style="{ 'background-image': background }" 
    xs12 
    lg12 
    class="bg-rp"
  >
    <v-flex 
      xs12 
      lg10 
      offset-lg1 
      class="my-3"
    >
      
      <v-jumbotron 
        :gradient="`to top, ${$store.getters.nightMode ? '#424242' : '#ffffff'}, ${$vuetify.theme.primary}`" 
        dark
      >
        <v-container fill-height>
          <v-layout align-center>
            <v-flex text-xs-center>
              <h3 class="display-3">Legends never die</h3>
              <h3 class="title">they live on <i>through</i> us</h3>
            </v-flex>
          </v-layout>
        </v-container>
      </v-jumbotron>

      <v-expansion-panel >
        <v-expansion-panel-content
          v-for="genre in genres" 
          :key="genre.index"
        >
          <div 
            slot="header" 
            class="subheading"
          >
            <!-- <v-icon @click.stop="">play_arrow</v-icon> -->
            {{ genre.name }}
          </div>
          <v-card>
            <v-container 
              grid-list-lg 
              fluid
            >
              <v-data-iterator
                :items="genre.items"
                :rows-per-page-items='[{ text: "All", value: -1 }]'
                content-tag="v-layout"
                row
                wrap
                hide-actions
              > 
                <v-flex 
                  slot="item" 
                  slot-scope="props" 
                  xs6 
                  sm4 
                  md4 
                  lg2
                >
                  <v-card 
                    :to="{name: 'artist', params: {source: props.item.s, artist: props.item.a, artistID: props.item.ai }}" 
                    flat
                  >
                    <v-img
                      :src="props.item.i"
                      :lazy-src="props.item.i"
                      height="200px"
                    >
                      <v-layout
                        v-if="!$vuetify.breakpoint.xs"
                        slot="placeholder"
                        fill-height
                        align-center
                        justify-center
                        ma-0
                        class="fillPlace"
                      >
                        Loading
                      </v-layout>
                    </v-img>
                    <v-card-title>
                      <h3 class="subheading fwl mb-0 text-xs-center">{{ props.item.a }}</h3>
                    </v-card-title>
                    <v-card-actions>
                      <subscribe-button 
                        :artistID="props.item.ai" 
                        :source="props.item.s" 
                        :artist="props.item.a" 
                        :img="props.item.i"
                      />
                    </v-card-actions>
                  </v-card>
                </v-flex>
              </v-data-iterator>
            <!-- <v-divider></v-divider> -->
            </v-container>
          </v-card>
        </v-expansion-panel-content>
      </v-expansion-panel>
    </v-flex>
  </v-flex>
</template>
<script>
// /* eslint-disable */
import subscribeButton from '@/components/buttons/subscribe-button'
export default {
  name: 'Genres',
  components: {
    'subscribe-button': subscribeButton
  },
  computed: {
    background () {
      return this.$store.getters.nightMode 
        ? 'url("https://www.toptal.com/designers/subtlepatterns/patterns/random_grey_variations.png")' 
        : 'url("https://www.toptal.com/designers/subtlepatterns/patterns/escheresque.png")'
    }
  },
  data () {
    return {
      // artist, source, artistID, img
      genres: [
        {
          name: 'Blues',
          items: [
            { a: "Albert Collins ", s: "YouTube", ai: "UCbwoSB3Jgv_K_IUQCj4xzUA", i: "https://yt3.ggpht.com/FIhR9EduLOtSe4bUz7UibBq7g2jRkfbQCoJfIuKJPHtwhK0OxCGOVg82HgVGEdhFL7ldizhy_s3vAepn=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Albert King ", s: "YouTube", ai: "UC9XFvJIqt0duVgnlvkXBeKA", i: "https://yt3.ggpht.com/GII3WrqEB6w89ZeDoV-T8-Lfar-QKzb1NSkX1ZJ3GWWsUD67BTfb96q4bUwM-atcgx0uIu1m9OmUo_PJ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "B.B. King ", s: "YouTube", ai: "UCqKrqzF3eX7R17m_MIMte4w", i: "https://yt3.ggpht.com/zXfjmgyPiskeWOb42r6k1_0xyXK4p9XGFFVOJUPjbPEkyKe9jhBqtTozypE4rUXjS7sKrV7wL0Q8-SI0Rg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Big Bill Broonzy ", s: "YouTube", ai: "UCP0ngc_IbrxTeSzQJ0YpGXA", i: "https://yt3.ggpht.com/GakC9u3wVhU95SVPskwiBiu-KWJFRVvX3h98bvO492rT7Vyy6O0mwLBX_DZSTKsFznpK8IebjwaxkURb5Q=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Blind Lemon Jefferson ", s: "YouTube", ai: "UCRfO0n1ycrnalER8PlGVlKw", i: "https://yt3.ggpht.com/VKMbiUuTps9hmniZNbuY0SBgBpYC5b8wUVV6AWf8TAlkVT_8cPK7g6F2FPEa9VGj9fXqJZW2afzbs9xmYQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Bobby Bland ", s: "YouTube", ai: "UCqEi91DIf1penU5yf67suRQ", i: "https://yt3.ggpht.com/QzapbjSUqmyV9UkhQPo_MgLS_EOKOA20sHg7pBBuCID9tgT1Vb9wGg0O-YAv3NShsZBTD9PDKPpmTW5Sqvw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Bo Diddley ", s: "YouTube", ai: "UCTXP0wPPSDAaOS6mXeM4tgg", i: "https://yt3.ggpht.com/3fHOxYq26zHdzZ39-w6dfgvSPKiTAxGEnR9qkKoSCxfkUjK2DQNFhBIxIYNX2Vd2oBmUCAx0KX74x9FANw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Bonnie Raitt ", s: "YouTube", ai: "UCt3dWNI94rZKmfzuwZyD5Fw", i: "https://yt3.ggpht.com/YXECJu-i2w0lyLE1FU7Z0IXAaN1V062RsxoqmQ_6nXSUbSRzYRLitipBkjBFz26QeF4U2GII1j1HbvP3Hg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Charley Patton ", s: "YouTube", ai: "UChgqUv_teGypvyjv4BpsLEA", i: "https://yt3.ggpht.com/LqJ8fqHwgeJo1Y6GWaJuK9sfm1uAfWNc-2xQYov2TArqank74b4SWrpwhwEwci4KjdLCVIG5f2LaT0uZIg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Elmore James ", s: "YouTube", ai: "UCcO7GQQk1W8gKWHkQDXZQtA", i: "https://yt3.ggpht.com/S__4ls2iREMDt1GxkYFBlUAbUG5fYzKl9i7KjNxPPi2sPzv9vQcKPWHtJagf11Lw2scGiiXQmn5oaCyKuo8=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Eric Clapton ", s: "YouTube", ai: "UCXmEE051j5RhUENn7saUF3g", i: "https://yt3.ggpht.com/B0E2vSeqRxJhgtEAgNeNzlVf6Enr-Nh2tu8Gm79GRILOasUVjpATE3fueagBO-8RVUK-AbJwRjMJfAIOMg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Etta James ", s: "YouTube", ai: "UCieyolnCbsWzyEt6wsd7lgQ", i: "https://yt3.ggpht.com/cHNrHviQpKhReMm-s0vTURU_s-mMPXSmp043hgtq9DNhpS9C-e-S_bDO6ANPvKjC8FfB_Nfk7Wch4m7AhJU=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Freddie King ", s: "YouTube", ai: "UCj1uIBa_uRRMR9GQ6wviIMw", i: "https://yt3.ggpht.com/NXm0kmowOVZqaqGgUu52Ser0vtsQBJyn3jQEVbpnjKTsJ7PDesguHtLguPFdFF1SmiVk6f56kaFTfQ1MPfs=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Howlin' Wolf ", s: "YouTube", ai: "UCq7KYdlYIAjlt2NbSEZD7bg", i: "https://yt3.ggpht.com/G2BGWXKPow39noOEkLgYBCDgFAPIp-mP554VSvPtZcoecbLP6RlehICo8Kp7YFoTcjXZbW5sQE4SAJObvA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Janis Joplin ", s: "YouTube", ai: "UCpxqHC9g0px9jecJ7WbfWag", i: "https://yt3.ggpht.com/8cI80PVQifDg3O0DxBe0-0v-XnVIaIiVliZl1aFfMRFKj99opB9EO4CJ40yS1eURHAGCwaUfuQOGq-1L7a0=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Jimmy Reed ", s: "YouTube", ai: "UCkJUdhq3rW7AElwDQ_omC3g", i: "https://yt3.ggpht.com/i1I3LzY5sssfNDenhEC2NdcOk4VSuHs6O2Xy5e7FR7OZJDUa1sRbgVSZrGS_RmWsI1zxnX73QmMNXx-ixg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "John Lee Hooker ", s: "YouTube", ai: "UCcWk0Z6iOwjUeycdoh7mIMQ", i: "https://yt3.ggpht.com/rMBNQAlL-_buKAWLznmuPMjAkskzkIj-W4U9A8YCYD9i5vSbtIpQeU3VLemJe_9u0SkTHu5GZ_sCSiGc7Q=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Johnny Winter ", s: "YouTube", ai: "UCdGP0Bisu7WfRtZdfuCqQdQ", i: "https://yt3.ggpht.com/GfqfNJ5V4bx9RlGHNNT6yRe6cx2AtqnNjZqDRYL9zqsyuwrbWOHs6yMbx6fvqKzoOsFtfpHr-1977_IjeQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Joe Bonamassa ", s: "YouTube", ai: "UCMmOiXQLPGwWUXHuLsO5Wcg", i: "https://yt3.ggpht.com/dWYGbdM4c108P_YPnHT0ShQRaHXuFmG5rHvdM-u0RgmC6-s1Ij87-5wnmKm8El5loIzrEqbZYpzyVgbb=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "John Mayall", s: "YouTube", ai: "UCwKfr_MVlpga_-acg6Q7u8w", i: "https://yt3.ggpht.com/M2jj6fLYDjLvCkC92t-_jVrrZxj6YKZ3ZQVRn5yKMvDeF-jw8nfAcl0r1aNzifI7-b3h0Ogv0N1Tbbwd=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Kaleo", s: "YouTube", ai: "UCe5SlSvnHTsnmBBXoFYXXGg", i: "https://yt3.ggpht.com/fQJP7N0MNkPO0uDgTJYAhfhC9HP-ED4lm1HNWtJ2l9-ZoLr3LgIzIyk6d6z9AgEMhPInmPrX8FFZLx56g6U=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Keb' Mo' ", s: "YouTube", ai: "UCjF3NlXbc67wlbU6f1stw1w", i: "https://yt3.ggpht.com/MnUccJVUtNrD72f6JnT_ae_y3PfkThPxNlfpbf_4db2EeUebzu08GiA3Bu_xWoG7MtlPk_0r6WygFAnUZg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Lead Belly ", s: "YouTube", ai: "UC7jiqF1wzNVeZhZmJ4EKprA", i: "https://yt3.ggpht.com/d7E-DRNZjX9u5uzRfrtvzTOb4gV1wgKoT0sNehiQIH_cLi04iPEDFa9Pv36v_2tY5dB9XPKlZwzUq2w-=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Kenny Wayne Shepherd ", s: "YouTube", ai: "UCGsOZPwTwFDKOs3O63Rp4Rg", i: "https://yt3.ggpht.com/Yy6dGewxFtRuK8n7GjvbPFTBTOZ1pFb_O_Mb6p3oyLA5UZlMv3w7uM0CSqjeNBVEDQYVPb0Dw4KMiSuSRQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Koko Taylor ", s: "YouTube", ai: "UCSpFymFQX2WBX2gNH0LQIDg", i: "https://yt3.ggpht.com/AYHFYLbERbBxybF0jV3P-muzl4QQEX89EF52jB85ebkiepaMnZigdy2cpKq3fTSYvL74c4TNvsxUIgMnJUM=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Lightnin' Hopkins ", s: "YouTube", ai: "UCC6-6kd-2eJJCtkHh5dCkiw", i: "https://yt3.ggpht.com/xQ5K0HIDX5u_MhxdKD0L1V5fqlekUVblNGlJh3MpkrhQUp5UVlpN0Wbqr_2xXue1ZVZfGF_RQgcDPCytkQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Little Walter ", s: "YouTube", ai: "UCbqLmbib9h4U6y6ND1ZPSaw", i: "https://yt3.ggpht.com/SjF5tzuCYUfEQcV-LP3AZ-Ch_nJZI_eTkK-QdPWP6kGwJn-9G6uDPn7yyLxLylX1zo1T0Ib5gag7oppQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Lonnie Johnson ", s: "YouTube", ai: "UC11_nfqWfu0m0tsob-o4t9A", i: "https://yt3.ggpht.com/mRlsm1XxtfGBK8SDGZMuzqHMUdYWoK7Bfu8T1t78gadVGLTUZF_3KT7_MxZXEMsMIADgL3Vf9CD7MmA7tPo=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Memphis Minnie ", s: "YouTube", ai: "UC44t62PL7ni6XZKh_WvXGzg", i: "https://yt3.ggpht.com/UJFwxnB2HIIztZFsf6iStRRYvg2uwBEjX09ZZ1IRhl5LQTp4jlsj79fGiz8McJZGB1tV4dU3FJKNDVZfkjc=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Ma Rainey ", s: "YouTube", ai: "UCh7FBIm6XgqYUQNpgdl9X3g", i: "https://yt3.ggpht.com/al3gTPhKQvf1NkmhVSLxb0wDiATVvLeeZ9euAYgrJjD3NAJmb3jCXJU-DtJBrb2oAgshOfXQxWJ8B8mIn0Y=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Mississippi Fred McDowell ", s: "YouTube", ai: "UCbNXWMxWD39iFkSGr1auS2g", i: "https://yt3.ggpht.com/s6V3FYac23DBXF8_hfVQDmtqn7C0_Ozy88_5fohNglNIuimLG5jzt-TRzzidGO-dgGWqejVfG4upT5lE=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Mississippi John Hurt ", s: "YouTube", ai: "UCDEcORxYIZA2yV7UjlBIuEg", i: "https://yt3.ggpht.com/zJTbzWUBNewJushmZ43X-o5CUuezHBpvfVFrgL0nmsgRc_GEuT4RaJ7KHUfRCBYyptIYxG0RncjgpKBxlw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Muddy Waters ", s: "YouTube", ai: "UCZ5YpKcmxGptLgRRW8ujxHA", i: "https://yt3.ggpht.com/9YsnfLnBbIU3kvlv24m-AljKJf_I3s3WoN8dUgOpmbU2Rr7CmN8gqdaLDVOvH3acmdTifcjUGz916DRS=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Otis Rush ", s: "YouTube", ai: "UC9_Ic6yumZhlfxY2sCjwKSw", i: "https://yt3.ggpht.com/MpymokACTTf9vAw2jFTGVze0HAPwmhIbixbPdnu8Zur9ECFJX83rht-nGNpeemcHqwqXzYFuJW3t771shQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Pinetop Perkins ", s: "YouTube", ai: "UCGloG-ofMo_rYixhmlaNAfw", i: "https://yt3.ggpht.com/UxcaR6to70iQiMWU3Y8UM5WhZ2UWxNFAhtp47cdM5ulZ05m_PsoAfjKn1Fv_PkTwsNNI9J3q2o4DLGspOLU=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Ray Charles ", s: "YouTube", ai: "UClapQBGYNOoLYmCct6e3B5Q", i: "https://yt3.ggpht.com/57gwn4rQn-482eV4ZR_W8VPan9Y39C45QQxbEd7-SEelh_aP-300NhRwKhC0tkDN_knDVFvf1wgis3Ai=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Robert Johnson ", s: "YouTube", ai: "UCjcp3ChO5oUZyx3f0FnGVUA", i: "https://yt3.ggpht.com/mMxRRnKre0wfW1QdzYJVad4AFhvxRuXl9PcpNwNKl0ZjmAPxWgmb8QMSf6AH7ISnd2_RhStwuyM4_terPEE=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Shemekia Copeland ", s: "YouTube", ai: "UCYc8lFXrJmnYM6j0bS3ib0g", i: "https://yt3.ggpht.com/8tapp6oUdPCXlH1UwlT0BwtyvftVzHD06aOi9K48JPNp3npUn1jScT4sUx4K4JId7c2gcm5yutpTa7FM=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Skip James ", s: "YouTube", ai: "UCOUlyPoyLeFd9QGtRuwGuaA", i: "https://yt3.ggpht.com/0zvLKO9XGoHwA7TkKsU5dB203eu1SsZwRzRabSeBvT7fbbM3aijjxHIY-SLYvCR5tSBm7KHGmxuIY6cv5Q=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Son House ", s: "YouTube", ai: "UCxo6H7Jta2YNrdk6a9cch6w", i: "https://yt3.ggpht.com/pdhwGY3GsWIM7sJn5vaC3MAauqxYadug4egvfi8IAtCETLtXv6Pg2xwuh6D9LWbzlk_1O9Kfk9P0Zj4e1g=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Sonny Boy Williamson I ", s: "YouTube", ai: "UCwW-vKTr3Rv9NPuXbKYaKOg", i: "https://yt3.ggpht.com/AJ08X3QsWsPbg8zd2TRDbVxfhpJ1fqnLnml4OF-o67tGIzkmYs2KWklCMtdV-jKoHepkQ0XjmbPhLCXi=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Sonny Boy Williamson II ", s: "YouTube", ai: "UCWEMaF6bf_6V2swH692S1EQ", i: "https://yt3.ggpht.com/6kxNoX06mY2eHicox6W2MfdqzViyoL-Tp7xwBPQsrb-3HwefyDTrewlSgRcny0fVMXHpzQ0FO71ivBqmsj8=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "T-Bone Walker ", s: "YouTube", ai: "UCGUpBCmvcFSZUekLZjQnJFQ", i: "https://yt3.ggpht.com/E7u97V7JRwHvM8RzXrOMQWQwEiU06X5gAHNtFWjo9KFM4c-5lxnx1yEKDr8g_tFKF3tJQBZoA7HRXCf6=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Taj Mahal ", s: "YouTube", ai: "UCylg6tzCZVAJrq5z4i1bgpg", i: "https://yt3.ggpht.com/dN7QbS_VSr087KMjknl-SDZWyd9yRPnxg9udYYBjWlkEHwANnogyeAfyNQpJ1yXe4IO78B-Fl3el91aX=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Blues Brothers", s: "YouTube", ai: "UC6SVhkSVEZxWOqSqvqZ6CSQ", i: "https://yt3.ggpht.com/-0BJz33qFh4N2truUsU6SCTO50AsNAx958AJ--Wb4-C_xJ3TDq6Xl3XlnRBOC2HbwQVX09CB5mA8CRwg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Stevie Ray Vaughan", s: "YouTube", ai: "UCna_2oi1hIA0FEWM_VoVfWg", i: "https://yt3.ggpht.com/VFPf4_gMcIQZ7bXhe4B_UUZHs9l_aUmaSVFbWdU8NXv9VrLsIlFuPnTRfp8W1TNclYbL3W8ogE0vyga78w=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Robert Cray Band ", s: "YouTube", ai: "UCQ2tt8Xd-dCcZB8wycA3uYA", i: "https://yt3.ggpht.com/03ktDrDJxKiPN6xVr9C8ZvEJ1cgcsBmF3JMAiRcJb_HJz2ywaWDXylqpU0ZSlOVqlHu4yzB6eb10IZTc4A=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Willie Dixon ", s: "YouTube", ai: "UCqjv56WoIUXuzrpdRUufR-A", i: "https://yt3.ggpht.com/WeeYzZ-qKl3PacLYXOGCb0noYeOr_B1JBiOzi1G8d5_bAalUSaKRg5U16Lc685a9f8rEuTOwPaZvgHMZdA=s800-mo-c-c0xffffffff-rj-k-no" }
          ]
        },
        {
          name: 'Classical',
          items: [
            { a: "Antonín Dvořák ", s: "YouTube", ai: "UCyfVmh0_CxWFkaGVAFF43DA", i: "https://yt3.ggpht.com/TgvWU3WYl6awMQrUmiIHmMxW_wVS8WG_g7AsSHz6ysZvlj2mDH0HOFVsAIw9Qruz-OSLaadimYGnc-Re=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Anton Bruckner ", s: "YouTube", ai: "UC9JDEVKTAQ7Yv5yNeeQIOBg", i: "https://yt3.ggpht.com/hT8vz6X1tsii8hAulSJ69SOTb3_ovLRNB37XfwQruW8DGbqFHdju49al5bVyx8mFIPqWC4OTlh9qUjP5DA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Camille Saint-Saëns ", s: "YouTube", ai: "UCXVWlhsX9o5krjzgrDXp5LA", i: "https://yt3.ggpht.com/rj-tn-8kOQtymLcFtavdBu2GDBq1gjvucC6fNcthVURYlWeQwfrfmv2WmWhSW9fgrswEnyWBo0k9m1mR=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Claude Debussy ", s: "YouTube", ai: "UCDBe28OI2PycHdECfoaIWtA", i: "https://yt3.ggpht.com/5v_v4u5L6Z2zsD6-sTqJA9QE6fnh6jpPaXtgkUMOZvX5VzYnmqLbCgLVnzXOXwowuq246Bq0ybnj6GkmoEU=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Dmitri Shostakovich ", s: "YouTube", ai: "UC3lycaAHUMxVt925AeYjMyw", i: "https://yt3.ggpht.com/Z5X_YeQgJpnLt1AeysGY-5_MWEpfz4WLggw753vtRcVygLgHZduvBvEsrjfKrLXeoxVLq05dajAmIniTj-I=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Felix Mendelssohn ", s: "YouTube", ai: "UCQAmb6sjnCdfoKvEy3hovrg", i: "https://yt3.ggpht.com/URDvUt8f1Lgnoczzi3JWlAbtejjHHVn72Kz_XZf5eRfuJ70rdI_DHv1tM9yY8Ug1bArJZbeBa175uNhG8Lw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Franz Liszt ", s: "YouTube", ai: "UCkBznkb-OKhnFmCCpuMvMqQ", i: "https://yt3.ggpht.com/pCVLGAbCf16HHdyz-jrx9fXvDcP_58Y61if43FDU4w0RrHTj6Q-gkwnFtOktX8yXbEqPPoX7iIVD1KfPCQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Franz Schubert ", s: "YouTube", ai: "UC7l3IFSPxafcH_GTj1VWTeg", i: "https://yt3.ggpht.com/j1eF6mnmiAyLuBbDmr5jDjORK-jj_wfPIp-EKki-eGeySD1Zw6cXTWotT6QkxNojWFmfEanI378n7N2qUA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Frédéric Chopin ", s: "YouTube", ai: "UCyTnUReB5s38R-ZKlb2wyVg", i: "http://bi.gazeta.pl/im/32/8e/15/z22603314V,Fryderyk-Chopin-tuz-przed-smiercia-w-1849-r--na-zd.jpg" },
            { a: "Georg Philipp Telemann ", s: "YouTube", ai: "UCH2VDieMiIjEXQ7N9hkWlsQ", i: "https://yt3.ggpht.com/VzmVhnqQt92ngTBxad9j4bc7YNJ46tVeKpoIuIp_1bdv5ukx0_w7RoEdlCS-goJAFuvCKOhpnE6zXTy-=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "George Frideric Handel ", s: "YouTube", ai: "UCA5lUV4mRfZElVdl9JsxkXw", i: "https://yt3.ggpht.com/QN4Jy0R1_t-3PxcItsjSTeRMEARzGVXa22iPnKlW89Pf0sYJiy5Kr8S7bsE0KiZFgobe3Q3gtgNPy7gK=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Giacomo Puccini ", s: "YouTube", ai: "UCP3E640nI6rYWYu7ab-U5Xg", i: "https://yt3.ggpht.com/YDS39fIw_Kl1BiNO18IlAflygMygCa_biIsaT5bF8tg1WKia65xnemxzad_Z_eA6pGdukDXr8k8ilWth5Ok=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Gioachino Rossini ", s: "YouTube", ai: "UCzKATHRxd8LnogmMSmZrfYg", i: "https://yt3.ggpht.com/R6a8BEnwKKIs8hVPB-GQ93HNC4bdR1nJnDmdbtWlha5NAi0tN6V9KsNELmFcy9HmsbNRh2ZqtzQN15-8R04=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Giovanni Pierluigi da Palestrina ", s: "YouTube", ai: "UCMwKgtgGiAwhFkP5nohtVkA", i: "https://yt3.ggpht.com/UNDtgI6wsihm6QEl9kgAZnnqTM3RiEyNti4dSmGavLGKlD607x7PvlxXRMbnCP-ZKwCUU_-tgsX_PYso=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Giuseppe Verdi ", s: "YouTube", ai: "UCqgc1-xfT1EXHgivjFiy2aQ", i: "https://yt3.ggpht.com/UKNZAhOkzHktyoIen4L2ufbDyZ2XuV-nYLsiJ3QsmRpMziSpeLb08PFIUJkDU8XQHlHDVcNAC8V1fXYQig=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Gustav Mahler ", s: "YouTube", ai: "UC4JndR9Jg60dqinZE45umxw", i: "https://yt3.ggpht.com/rQeoTuEc-AwjHk_Hoc2YWBMR0FO6SdtYoIQm-ojxFS2csc7BLUzRKRFcmE5x6TZl9EvVSZIeYn6940YuQ68=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Hector Berlioz ", s: "YouTube", ai: "UChSnG461wXJZm0OmCUuTJ9Q", i: "https://yt3.ggpht.com/yuNGCkmKu3YrJUmL0OA9tVszW8UEmuDz7s5fjnh0sr5CgjtOaas1bRJiXPR8Z7_Xbkw1l2YRytnmppWKdw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Igor Stravinsky ", s: "YouTube", ai: "UCELh0PB52k1uiZP91LKW9VA", i: "https://yt3.ggpht.com/HGcttvtP1WlT19U4OXyB_50sPSet_OlOIBi2Ivdw7n-BWF5hEg4HxWCcDS84psz5YXvPNdUhQ48VAvE_=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Jean Sibelius ", s: "YouTube", ai: "UCAwzejYabpZgGWVPTvxlJ_A", i: "https://yt3.ggpht.com/2qMCXD9z7-iw6XFzVAakYTk0sAlwTYZhzqoNXDO5Ce0bEEzZ2XlbRmwCKgbkQdTzNKLcJBSw5SoUtfgukw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Johann Sebastian Bach ", s: "YouTube", ai: "UCFtSXTlIMFFkyJbHO3V5b7A", i: "https://yt3.ggpht.com/KRS8pAKoIDomCAiqfEfNceaGorADvhvyYaLuuXMTxi8tCFfhltV_E9yTtKgktalL3ywXwCCOOC1iMK4scXo=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Johannes Brahms ", s: "YouTube", ai: "UCJtFbUvNYtWoVPw_xraB6sg", i: "https://yt3.ggpht.com/R-iMMo1XSr7Oya7iGmBoL_qfov3mNDl_4VS5c0pHqsZxepAH16rGKF6KZosnvBwTPQwmMN5XpWEy-h_T=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Joseph Haydn ", s: "YouTube", ai: "UCyHvFhxUFcB2zVW_4cT4fiA", i: "https://yt3.ggpht.com/zLA9nzPPRQqvm8KZS161LuJjgIYHu8CyV4xemnU2Szdp64nCQh02pBC-m9wSTlEd7hMRRfnlfnPu5aUc=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Ludwig van Beethoven ", s: "YouTube", ai: "UCnsAooIr-Dsr8zJOCSadQcA", i: "https://yt3.ggpht.com/c85bE-_67CI5MdkSfY34J_PQ6byxfLSUakHd1JB2d8aGH8T_mL1mDMDd_XrbXywjSXrxkqm9tolDn0J2BQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Maurice Ravel ", s: "YouTube", ai: "UCEWr3HmyDujG9n21iAUAJYQ", i: "https://yt3.ggpht.com/UcacWPw2ubmSVaKHHulDzlrFBRZHyspuirOo7zoFEh41TZfh7gQJ595PiRW3e5YIdQrQv7GJ9qy9mTI=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Richard Strauss ", s: "YouTube", ai: "UCxa1rtpzfnbgV7JxZjqGLxA", i: "https://yt3.ggpht.com/ZBkz3SIOT_NuwhNMY3DB_fd0WuFajm0WD1-GmyAGoIqatfCN3hAsilhdY1JQcQBY6tQO6roP9M-ZlH8VCw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Richard Wagner ", s: "YouTube", ai: "UCqRT-aGYojd-in6xTOT2-OQ", i: "https://yt3.ggpht.com/h2wn9_p8v5QH2dJg_u10ZvHIhwTMCuRS79LHT1iYOYCgu2UoYYT83sG9KX1WJl7OxNW8nnhek_ylVvKndw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Robert Schumann ", s: "YouTube", ai: "UCTqyZnhFNMHrDYt6hANBcew", i: "https://yt3.ggpht.com/jyBaUbdBSAj4mmMoZixQfg_P1Y1T3xmg__rQycoQmdvNQHmsmRucRtl87uQOqQBaiPhyFfuZ3UKaDUD5gQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Pyotr Ilyich Tchaikovsky ", s: "YouTube", ai: "UC6UJm5ElaATOPzXxNkuLDJg", i: "https://yt3.ggpht.com/MZGDAcA9JjiURwul4gKZGt3N9wr9Uq-h9p8jjzbmDUU9O11ZLwDAzFigDxXWkuKQeEIA69GkkEtJbOqI=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Wolfgang Amadeus Mozart ", s: "YouTube", ai: "UCmeFxYk5BSbJGWN9OgTAIhw", i: "https://yt3.ggpht.com/GnBd9_FYHq2VCMZOB_8KSCFs7u30AvJKx4EO2mwUDQxjk7NTrImpm9TpVE_nnnLaK1DVyKINUiQsmLfj=s800-mo-c-c0xffffffff-rj-k-no" }
          ]
        },
        {
          name: 'Funky',
          items: [
            { a: "Average White Band ", s: "YouTube", ai: "UCN-nei8O1bNhTWh9J2wnBqw", i: "https://yt3.ggpht.com/A5zsEH3sxjk6AOWsO5JQqLMhWkmN2Qc6Zw2jFHPZMwt8BQyZMaxgGaGPIk5XLgP0T9GUo_USczy5xd5_zQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "B. T. Express ", s: "YouTube", ai: "UCJQat5mH7Bj9MGaXW5qf0jw", i: "https://yt3.ggpht.com/TE-Ome_0H0Xq-CZMeqXVkOd45gwT1Ab95xLbJFNAQwgirm8MXbfkC3-rp8Pu9jRMLPltHJNmZSGil79L1S0=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Billy Preston ", s: "YouTube", ai: "UCk0o3_qkXiJn8ZNiIoAOWmQ", i: "https://yt3.ggpht.com/rBuw4WM8mQMqVSid9Qvm63TM2JxG-5D-bU4r-9rloHtJK5g5cKd3Um9L_TKVB4Tj4J-I54RErj4gSwa8=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Bloodstone ", s: "YouTube", ai: "UC-z041GhzcHWymkdGzfmZEg", i: "https://yt3.ggpht.com/Dvqk4lclGWyeVUxt7ZAEi9CnA3kyWJhHUuxBPw8w9CDnmITIRWrUfKKIeV2bfwrUgZfAS6Xf2_xNh4VtQQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Bill Withers ", s: "YouTube", ai: "UCDjpW6k2Sfg_FTr1toLvffQ", i: "https://yt3.ggpht.com/mTs8P7VGKyoDbYPS1WOjBlP79-K0gGPVTitryDSMssUsIV7fkv__oC2u7PF88z8_WX5kynk4Ao0C6jnDXQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Brass Construction ", s: "YouTube", ai: "UCe0E-P0V4lvzOLNZBdu5Y3Q", i: "https://yt3.ggpht.com/h9ZbRFthZeJr7qIywCh5R97-6KWllTgXsqI_gxmgZ_mphhIKA680qqZ4NpVYl35q40jAT04UvxYUeCbFLw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Brick ", s: "YouTube", ai: "UCNKjjE249Qo3bRUxxHMqiKw", i: "https://yt3.ggpht.com/pG0JeGTlcA9QIZlwR7Y2fBNV1eKtO0t5yqjHF0L-TIxjcw5Bk4vvt2daJoX4W2MPcDIuNOwMmIzrm_x5=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Bobby Byrd ", s: "YouTube", ai: "UCOuELTDB8DTcxHB9C4YsWuA", i: "https://yt3.ggpht.com/c-hiOU1f6sLkhZfkEwF-KXxD2RH3dS573Lw4DklKIXtYYHaJM21cqZES4G3DQHnn6wWSjZykwltKC5JQIw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Booker T. & the M.G.'s ", s: "YouTube", ai: "UCdKp3x36Zt3B8OPGvzqIm7Q", i: "https://yt3.ggpht.com/II0fddt9nS1mWCDGSLi7nsohNZ4a6RclISLNc7ov31V3kK8YmvBvrxUGsDkjIHMpYYOd5HSYfwLxRHxd9w=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Cameo ", s: "YouTube", ai: "UCWOWuP1wrpPtdpX72l8jl5w", i: "https://yt3.ggpht.com/HIDxUi-kGKbNbMsfqFiFICqMzW__PQx0wY2Kgi614Sef3IPJzxj1e3acrs2iLIZ3m6VKU0XOAnpjrcsbXIU=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Chaka Khan ", s: "YouTube", ai: "UCwRmRZFN_nTAkKZYngL-x6A", i: "https://yt3.ggpht.com/MRS0u7pEL1TlTzp20ZcKVZpQPOdbB8Rsz0VAhr4zLfTFtvHa4H4x8MDdI0IBjUOtEfU6Ct8bFzzgi758IQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Charles Wright & the Watts 103rd Street Rhythm Band ", s: "YouTube", ai: "UCvL2uCvW1RAcsYkdEeEyeZw", i: "https://yt3.ggpht.com/iYGUvySwoCOOGHY6FS-GxbkvMV77HtTuUHs_XYSayEC98N1L0vZl2WFLag_R8KzrYcvfWuFtdkohEcDk=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Chuck Brown & The Soul Searchers ", s: "YouTube", ai: "UCFwshR1mhG4oyQ7Xp3N9FCA", i: "https://yt3.ggpht.com/eR_Gycf7c7qo7HNp72R31eWCSMebWuNvdevmdkR0894VIjWLa4xVdFYT3k1pBcnXa9NLGtRyaJq-C2P6EH8=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Con Funk Shun ", s: "YouTube", ai: "UCtrRS6QwswmaqX2YRtzwvww", i: "https://yt3.ggpht.com/ll8s7o9_ErQhqUZES9it_TwU23yp9mu-eD--QCIYsdQ7WO8w9sGmPDcKr6NW6pEw3JvphWe6GOx7fDkghA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "CommodoresVEVO", s: "YouTube", ai: "UCd6zd8v3DAt19QDDcq7_TsQ", i: "https://yt3.ggpht.com/a-/ACSszfFJ8BQmUn5jNUi7B72VdB1rcB0auz3-PAEAuQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Curtis Mayfield ", s: "YouTube", ai: "UCJmw3MTR4v8eYIGm3N2zRLw", i: "https://yt3.ggpht.com/oPf3c24oqRNZyDaqJvSDTahF2aGAi7-5L-gTDLLSal2L0zkxzt0FKeYLuHqOuzxsxnLEIcrt-5exEoJl=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Dyke and the Blazers ", s: "YouTube", ai: "UC4thWyh4CgkIUit7z8Ak6cw", i: "https://yt3.ggpht.com/4cZdr-vDgQaFpQ-SVyaNT77ltXKJTMQC95tZKOsU2DUOiPiCPFUQJZwi27Ddl45XyDld2DbN6wkMOUgEiA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Earth, Wind & Fire ", s: "YouTube", ai: "UCdyqvgHHq9NEEfV20lO61jQ", i: "https://yt3.ggpht.com/TLyvVx0Mf1jivVZaNMwc3QPeI3mW_Z9cfHoZ1of_yjQVmxZaZbv0N1Sdi_-B0U739E8hubC1cCiwsHvMpA0=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Fela Kuti ", s: "YouTube", ai: "UCoFUl09hePTptc4UOSISC9Q", i: "https://yt3.ggpht.com/7LDj8BmchyxzcnS0jRIYFuAM83S6U_2MoQiPVo8tRAhzUalKhfA3N2YbvH62q7U8sZL3rYCCwUqJr0EfBw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Funkadelic ", s: "YouTube", ai: "UCKwWf4e842gO9cY0YJCfe2A", i: "https://yt3.ggpht.com/LUK5dLotjZ_vCsMsVGBJdeLoJ0olhj6ItNcZBG1xIfgKvqJPtPVzop0sLpC_tAsBV0X0OJeQG8cxaJxQoy8=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Cymande ", s: "YouTube", ai: "UCIWFx0nG2yp5URl3z0IofXQ", i: "https://yt3.ggpht.com/SNcbDgr3T6UoJsuopfgI4yNbg4kpB5JZ_0upLlyTpsZDReLJPi_-5xZ2fXRHFu2kSSV7PZbykiy6v7tbig=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Fred Wesley ", s: "YouTube", ai: "UCv6yOvGBJg9x6fkKZ3xhHtw", i: "https://yt3.ggpht.com/JtKINAlk1C7MJ0igR4nf40BEqDNUZt-QCZCW9Wn5T0AgaBJaYUnGlJm7FMjbkxB-YILhdsBM3ty58EWGpQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "George Clinton ", s: "YouTube", ai: "UCtxum8RNo3iBPhthXo96GZQ", i: "https://yt3.ggpht.com/ZXAk7KtCo2MB5dTxYakKwJhoUb_q2-3glIihIibGC52HrmHG3_sl-UAhmGpeH2129fsx1otYsrdfx1-2=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Gil Scott-Heron ", s: "YouTube", ai: "UCO78NEi7Y7J3HKFuPke0LoA", i: "https://yt3.ggpht.com/dj1e2K0yQCQrOWfQyvYn1_Z9iteahVxd9RBH6gg69e3a4NBcyatAYePZIl8rz5EZDKvUHV3ypU9CVzlD=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Isaac Hayes ", s: "YouTube", ai: "UC8CgmVlKFWdFr3e3JH-QnVQ", i: "https://yt3.ggpht.com/Ij6ZlXuGHT_wFTGopSK0ttlmE75AJJZwKFbFfhNPWh6Jn6yMmUK080Ut8Vw3MoMaNpIb_5nmPHccHgZrZg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "James Brown ", s: "YouTube", ai: "UCLSKiNGc_qBWJJ-m5y3jDEw", i: "https://yt3.ggpht.com/Hop092Oouu_Aj0p6k7dP1b2Rp7hGBHMQGnXB8rp0HW9g6iO7E-DhRQf9-flzh_ZTiCQo8h3-sdZNfosf9A=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Joe Tex ", s: "YouTube", ai: "UCz3M1bRDfweNCLekCjbcCqg", i: "https://yt3.ggpht.com/YSBKTHD8MEtKW8EXWVt5KsFnC9Qj4krKzMKUUCT0wXY3AcZOjQW3S_qKYfLsgNjtFfCz_HpEO9X03ljH7A=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Kool And The Gang", s: "YouTube", ai: "UC44z3Xy2dA0dM3ql1hgrwCw", i: "https://yt3.ggpht.com/GiF9sI7Q5ZLGidRmwSZiSLqw1OZHMXMU36a7w6fjG7vd6YwxIfvtH-tPpCi_03qtTcxCfw0QUpTFDvEmVyA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Larry Graham ", s: "YouTube", ai: "UCNrEGX4bHCGGx9pscUDJ22w", i: "https://yt3.ggpht.com/JGhRe1Z7WvXZ3mxZVgeSF-EZTkctHyNjsFeid7Y6PYz_p3wZM-iznElaVIeGgoVEnwZT8I-egHVVbORInQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Lyn Collins ", s: "YouTube", ai: "UCkkeH8mXzc3RA61xpCsKK_A", i: "https://yt3.ggpht.com/oCDU2skl1y0j5wt_2pKhZPKc_FEl7jDSlt5qLQpzvJdskWxVCSjLBV1OSxu176cGBY67nGZQCmON2WLmbg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Mandrill ", s: "YouTube", ai: "UCaL1EuAfRlYUS-BnEoTLPdg", i: "https://yt3.ggpht.com/jFtGJMJJHllqAXudLpWBiLZuxamE8GndE1uwwLRGwzT3mqzXtlD9u-tHTCfe_aETFbqTzDNKCIWW7L8P=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Marvin Gaye ", s: "YouTube", ai: "UCpMMYJB5GJAYSJr3QpxnHEg", i: "https://yt3.ggpht.com/xsuLy917UdhfP-gcS9naVWNBQgL9JDu9rP0xXOWPUL4BRrVICFOX6umU10gtKi9zBBtl_WqQLanEsKsu5po=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Rick James ", s: "YouTube", ai: "UCBSe49693vkjj_OJ9b0ggUA", i: "https://yt3.ggpht.com/USyyxXyj_3cPleBh_WXObT7mdGoq5kHRiEFWtWSwSI6_Ym_SleA-JUr1avCG07gELH_qoLnmPMigsJRWZPM=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Rufus ", s: "YouTube", ai: "UCV-ePMa7s-AqUtVYysArFug", i: "https://yt3.ggpht.com/Ldu4_t50k99gOl36iM4rUFg3gBy1LcNvZ6jdHwWc8h_vt5k544Q97dyVxyUzPZWyE3eku0xr9cL2sPfLUFk=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Rufus Thomas ", s: "YouTube", ai: "UCm1Njiat5P7x7ftWuNZi1tw", i: "https://yt3.ggpht.com/0FFxqUEdqkKjOAA3vGh4__fTpC5a5NOkmkccYcQkATXrlG31fHu5fU6wWRtfSfN275hIPTq8ZicaiEW_4Q=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Parliament-Funkadelic ", s: "YouTube", ai: "UCCHKkq9MfwAccClcx3H1cyg", i: "https://yt3.ggpht.com/Qazbmn9zOgioa2DBD_UDZwPG5NEkNhQ7eD2WmSVF-Bqun-DCs0sW5k5dW6_WG3GMhICq5NUzGAH2jc_oUQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Prince", s: "YouTube", ai: "UCv3mNSNjuWldihk1DUdnGtw", i: "https://yt3.ggpht.com/a-/ACSszfE5hPNSlSdAWjLV8pOiOYQR03F6ACiUlOPaUQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Ohio Players ", s: "YouTube", ai: "UCOJhJ8Oyf5FD5brohb_g1fA", i: "https://yt3.ggpht.com/I7dRH1qxFi3sri_TjJ2VqmRneUb0KDTVezwELtlRLX8IQtm85fqmA4VULgEkHUjt15jtrAN2ex85tGM5zQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Sly & the Family Stone ", s: "YouTube", ai: "UCgwJnBJfprQYGX3OPQrTvqw", i: "https://yt3.ggpht.com/5uaebob7CYKjLosrD6kajZd3LzLF3SNVpHHN3zpSH8LzyfXKWNOj7wynvToldu7WMQvgTZBQHrMWpjLyICk=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Stevie Wonder ", s: "YouTube", ai: "UCR83RRXHzXrEQbu_ZQmPMSg", i: "https://yt3.ggpht.com/47betGyAuqFu7YSxXPwCv1SzLLHICJxFsVKxADc-El180-KRlk7DMBun7fXeH6-NoUNR3-wUFJCnkPM6jg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Bar-Kays ", s: "YouTube", ai: "UCLNOvQ9MA1CYmF5joGC9ePw", i: "https://yt3.ggpht.com/nyF_CKEPZYDZMohn_QqkMIe8pQFX-Ogc1Pyjfi7Uio0ZyqpAfn8JxwNpyYM2f5wIMxeGiVGsoT4h_TdJEw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Blackbyrds ", s: "YouTube", ai: "UCFapEGcJM30OJsYjBMWjHmw", i: "https://yt3.ggpht.com/FYB3LCn2KPiCSBRowaeTCzy-yho9LhAl3-kTO9TVOccEXrd_WiE7rUlmzlznSAf9-bduPH8de-HVpG4G=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Brothers Johnson ", s: "YouTube", ai: "UCc2g6yb1eMJ_-OPE0qAYImA", i: "https://yt3.ggpht.com/avHUdapuW8gbnLw2fKqwbaY0OQLEaDrlCJfaH6kTJZsrX4vAdNrckbVPLuukVVnCUzg9qdhEtzkZKDS2=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Gap Band ", s: "YouTube", ai: "UCLlCPIaPLOugvMKyt0Erllw", i: "https://yt3.ggpht.com/yUwO06ZoPJAdJnhoRdVBaCEIq0qBV8CWa5uiP8Ioq7JvL2JKIvPjhAb7oecjk8pniaPL_nnCqEvdUfzzXw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Isley Brothers ", s: "YouTube", ai: "UC19gd7AQcPkrcFH8w8BYO7w", i: "https://yt3.ggpht.com/0WylIZo2lnS1HLejC7vLSJmmCnsypw4IXCd05o3qf1YWjBcla42wYH6BqaSlFtVGCKdiMvQ8F3sObD2w=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The J.B.'s ", s: "YouTube", ai: "UCH0J4AgVPF-krK6K9Ykav3g", i: "https://yt3.ggpht.com/Hp18LseT2yfjBevdURk8-mfZfq2QElIXOOdSUliVuLJYl0uS1mpAHh4z17Gh73xCYRfizMmIhydsEIh3=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Meters ", s: "YouTube", ai: "UCwye34yhtCbWGQsrFS4oMNw", i: "https://yt3.ggpht.com/wx0MnVmvY4ZFjuO3IwG2gA1OUMO7YWSR8lmnVteiHUoPusbKZir0XIiE0rPwoTnf2OZSROQWfzg6i5sZjQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Temptations ", s: "YouTube", ai: "UCwWtKZD4xNVpEHndNxYu51g", i: "https://yt3.ggpht.com/uHghZbeZWRiaf9ENvCndMmD4gDaMADSq9gutjZ_JpzlouGN_NuIGN4En-wbX6CZIZrwmO7qBF1AUXBrpUAM=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Tower of Power ", s: "YouTube", ai: "UCkSrbTm2YvkMiVopasi5yHg", i: "https://yt3.ggpht.com/9gLnulA52yWgltiXw9037MEUrj6W9Bwxj3c8c53jVODZiN6Ws0qKp0PhN62p6HXWLKNxeY08nRO7COajDg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "War ", s: "YouTube", ai: "UCY9rJimufdb8imofVY8taNw", i: "https://yt3.ggpht.com/SQezndTYaK404TiV_YRuEeufUjVU4t9IYFKtjv2dzfE-qhblvHxbGDg2ElvEMCTBIN5gUscrimwzNJzUDI8=s800-mo-c-c0xffffffff-rj-k-no" },
          ]
        },
        {
          name: 'Hip Hop (US)',
          items: [
            { a: "André 3000 ", s: "YouTube", ai: "UCqmZ-EtD-ExXjF9Y28LbN2w", i: "https://yt3.ggpht.com/-89uYsz5Ncg0/AAAAAAAAAAI/AAAAAAAAAAA/WwFCq0s23XE/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "A Tribe Called Quest ", s: "YouTube", ai: "UCiOPPAw9e2Fj-i2uMNpoRNQ", i: "https://yt3.ggpht.com/-rre4QQJR4fI/AAAAAAAAAAI/AAAAAAAAAAA/KiZtoLItS54/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Biggie", s: "YouTube", ai: "UCczXQ2ehGOS2U2UnR8rY3Hg", i: "https://yt3.ggpht.com/-zwF-wkDznZA/AAAAAAAAAAI/AAAAAAAAAAA/JGKUyFA6kSM/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Chance The Rapper ", s: "YouTube", ai: "UC5w8FMeCcC6DG2oWjGgyHKQ", i: "https://yt3.ggpht.com/-gXR4QZRwaM8/AAAAAAAAAAI/AAAAAAAAAAA/XvqeyTEf0Ec/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Childish Gambino ", s: "YouTube", ai: "UC4hvOh5lgkeAJoVRIg40Kgg", i: "https://yt3.ggpht.com/-dDnswIdzYy0/AAAAAAAAAAI/AAAAAAAAAAA/6ckYCiLuzaE/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Eminem", s: "YouTube", ai: "UCedvOgsKFzcK3hA5taf3KoQ", i: "https://yt3.ggpht.com/--xXeTBXLPxg/AAAAAAAAAAI/AAAAAAAAAAA/nlYuc-4khFI/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Fat Joe ", s: "YouTube", ai: "UCvujFDDYFSt0uu_aTxuVEIg", i: "https://yt3.ggpht.com/-mOmzMxTQ94k/AAAAAAAAAAI/AAAAAAAAAAA/LkZRcgZ02QE/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Ghostface Killah ", s: "YouTube", ai: "UC9BR9FK85Ez13EZ34Z5yZnw", i: "https://yt3.ggpht.com/-F5M39eFV5eU/AAAAAAAAAAI/AAAAAAAAAAA/_SCTFhmxwOc/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Jay-Z", s: "YouTube", ai: "UCbJG1HvzgzaMe_15xfiUyWw", i: "https://yt3.ggpht.com/-8YpxFUUY-TM/AAAAAAAAAAI/AAAAAAAAAAA/LEOdbUCU4GI/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "J. Cole ", s: "YouTube", ai: "UC0ajkOzj8xE3Gs3LHCE243A", i: "https://yt3.ggpht.com/-zQD5wWXbLGo/AAAAAAAAAAI/AAAAAAAAAAA/f1btzqOIw44/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Kanye West ", s: "YouTube", ai: "UCRY5dYsbIN5TylSbd7gVnZg", i: "https://yt3.ggpht.com/-Ugk0XEFMnYw/AAAAAAAAAAI/AAAAAAAAAAA/871SBFT4r_M/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "KRS-One ", s: "YouTube", ai: "UCA2w3yf1BlliMJoaT-vFqaA", i: "https://yt3.ggpht.com/-57spDHSpFt4/AAAAAAAAAAI/AAAAAAAAAAA/Dui6NJJzXJY/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Kendrick Lamar", s: "YouTube", ai: "UCprAFmT0C6O4X0ToEXpeFTQ", i: "https://yt3.ggpht.com/-U4IAIqF-0Ds/AAAAAAAAAAI/AAAAAAAAAAA/DBxpvCtz_Og/s800-c-k-no-mo-rj-c0xffffff/photo.jpg "},
            { a: "Lupe Fiasco ", s: "YouTube", ai: "UCe872mgP4deADPnXtkbS-Cg", i: "https://yt3.ggpht.com/-2uA_GG9CQcI/AAAAAAAAAAI/AAAAAAAAAAA/X1F0VBxNKrw/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Marshmello", s: "YouTube", ai: "UCrxpwXq8wCTskOQq5d_KoqQ", i: "https://yt3.ggpht.com/9dcB7NxE1pSUBeDtdUYaWq_1D9Y8ddlKaFGTGYsDN-5GE2osXqoYqPQGOdpxAC3F77aEZ0VC1WtIheQi6g=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Meek Mill", s: "YouTube", ai: "UC9HlWVtENbiMQzVRmnbJxtw", i: "https://yt3.ggpht.com/-JQ7o4jFezHg/AAAAAAAAAAI/AAAAAAAAAAA/r4jOdHvDj1o/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "MF Doom ", s: "YouTube", ai: "UCooTDYkIERWBwDC1JKyoElQ", i: "https://yt3.ggpht.com/-gr_qUgstg8w/AAAAAAAAAAI/AAAAAAAAAAA/lpoKpV4apPg/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Mos Def ", s: "YouTube", ai: "UChAY_qKqbGyqau8q1gXkzww", i: "https://yt3.ggpht.com/-YEFnc6Z03oc/AAAAAAAAAAI/AAAAAAAAAAA/r-RivCPh0Bk/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Nas ", s: "YouTube", ai: "UCPoQYATXIYvN5WB0c4f6jfQ", i: "https://yt3.ggpht.com/-Ikwhe8HZwSU/AAAAAAAAAAI/AAAAAAAAAAA/U01pYxjJTvc/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Raekwon ", s: "YouTube", ai: "UC5xA-S_yp5X9nRWM8d-Iheg", i: "https://yt3.ggpht.com/-r4165cAY23U/AAAAAAAAAAI/AAAAAAAAAAA/AmyTSrSHMgs/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Rakim", s: "YouTube", ai: "UCFMS1sbij1WaZzZpnBDCs3A", i: "https://yt3.ggpht.com/-dq4gbVN1SnY/AAAAAAAAAAI/AAAAAAAAAAA/fOrEIHoG6HU/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "RZA ", s: "YouTube", ai: "UCS9E7hCpXnbB-UFlLXgGC6g", i: "https://yt3.ggpht.com/-AJsO62potYE/AAAAAAAAAAI/AAAAAAAAAAA/uMynUQZl1Wk/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Tyler, the Creator ", s: "YouTube", ai: "UCcLpRCcpXhhftxKu6rXGhsw", i: "https://yt3.ggpht.com/-Vehq0Eg8ybs/AAAAAAAAAAI/AAAAAAAAAAA/1w2E-AaKXe0/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Tupac Shakur ", s: "YouTube", ai: "UC5RrGzC-JXglhFW5NhT4r6w", i: "https://yt3.ggpht.com/-TqUchB3TfFU/AAAAAAAAAAI/AAAAAAAAAAA/IQNJFO3JQuI/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" },
            { a: "Wu-Tang Clan ", s: "YouTube", ai: "UCdQKMtGgbbahJWE3rkPaGoA", i: "https://yt3.ggpht.com/-9OpDgAUuxXA/AAAAAAAAAAI/AAAAAAAAAAA/B72BZk-XfBo/s800-c-k-no-mo-rj-c0xffffff/photo.jpg" }
          ]
        },
        {
          name: 'Hip Hop (UK)',
          items: [
            { a: "Akala", s: "YouTube", ai: "UC_0APG-7L03BMrh10wgdxHg", i: "https://yt3.ggpht.com/SWol5AHZbv_DMSQr12CHawWQrIA_8LgoYQrsKxPpad3TLZ1kIMT0XbeqMyUfXMqT_g7yAA7W7c5wW365nA=s800-mo-c-c0xffffffff-rj-k-no" },            { a: "ARTAN", s: "SoundCloud", ai: "210400488", i: "https://i1.sndcdn.com/avatars-000503285910-ndpme4-t500x500.jpg" },
            { a: "Astro24seven", s: "SoundCloud", ai: "173379119", i: "https://i1.sndcdn.com/avatars-000412508427-pkj4wt-t500x500.jpg" },
            { a: "Bisk", s: "SoundCloud", ai: "46254126", i: "https://i1.sndcdn.com/avatars-000408483978-dp5blt-t500x500.jpg" },
            { a: "Blah Records", s: "YouTube", ai: "UClBsDBGwEYnt1GWWq4mMiOg", i: "https://yt3.ggpht.com/a-/AN66SAxp9KiBPyLPxkkoE_fEMRW0YFS2ZkURxJ2q7Q=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Blizzard", s: "SoundCloud", ai: "6985766", i: "https://i1.sndcdn.com/avatars-000201090280-q2fj7d-t500x500.jpg" },
            { a: "COSMIC%SEAGULL", s: "SoundCloud", ai: "195601003", i: "https://i1.sndcdn.com/avatars-000195638855-7lijh2-t500x500.jpg" },
            { a: "Cult Mountain", s: "YouTube", ai: "UC4MR4pqJYgk9mfr2iPwub7g", i: "https://yt3.ggpht.com/a-/AN66SAztlGI_i71s1AA7nlePp2FI0HstgJD4qS5qMg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Cyrus Malachi", s: "YouTube", ai: "UCx2nYhHJdla7PCUugk0FR1w", i: "https://yt3.ggpht.com/ESulqpwGu1Hjx0lwF7QBoRYU47VTmwkyfgJoCdhm9pkxIml3XHP9Qgu4XpFtbX7P-Sr0quDBMTFpdHpTDw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Depsoul The Dutty Pirate", s: "SoundCloud", ai: "57581973", i: "https://i1.sndcdn.com/avatars-000100167872-8540ki-t500x500.jpg" },
            { a: "Dot Rotten", s: "YouTube", ai: "UCiNZYi55E-R2L9JUGSDL4rg", i: "https://yt3.ggpht.com/367Jch3MB-1tkNLwPlee0065xtSo-KXnXqD_1d65SJvPKBfaP3X_2HH14NsLkXAbU1UKB-9M1P1x-I33=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "D Double E", s: "YouTube", ai: "UCXPGocl5bXkB2jGBseFMMkw", i: "https://yt3.ggpht.com/VBp1PF8bc9Pd40ZsRj4f4-RY_u6SZurtIV1shec8NJLb-jIW9Ex7nE058GrPVLwD4yAjTIEKFYAZx3HYK9s=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Footsie", s: "YouTube", ai: "UCW6fEGXKgc2vBJJdZ--xoHw", i: "https://yt3.ggpht.com/8RZejCiXJqqoyJno5w3hGcxEwBxU4Li5ctNOqMxFu8KsTpYZdlWU4HlHRx8DsZk-bRq70_pyu6x2sbf8zTg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Foreign Beggars", s: "YouTube", ai: "UC4H6pt1c75dUxbd4nEkKH7A", i: "https://yt3.ggpht.com/-ldrjIiQNev00M9smb-38cbk7Ar_5zCC5kQbfa-2OdXraEhEOiJ7VMzgMbIqUupDNjlE5dVDHuHrkcaqpg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Ghetts", s: "YouTube", ai: "UCCmxgTzGmR1iBREYlC7VV7g", i: "https://yt3.ggpht.com/JexoxEe-1SMNS0_oZCJsJzfoOu4IbHaZqt_CTobjLPJ_DrJF4M6giA3dv0uU6pPV6PhNdh7mes3am8DI=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "HighFocusTV", s: "YouTube", ai: "UCsdSVUYgClqB4zGU_yfQSAw", i: "https://yt3.ggpht.com/a-/AN66SAwBBO2OVzpzLnLmlNygLIJu4SCqkTM9D4Lpiw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Kano", s: "YouTube", ai: "UCX0eAghP7jrWHWfYBAhrnVw", i: "https://yt3.ggpht.com/a-/AN66SAxUplp22puKwoU_wdtSKKDR3yXqt1Td-oj4ag=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Kyza", s: "YouTube", ai: "UC94hlcbanf0mmBUBj3ynqIQ", i: "https://yt3.ggpht.com/E03K5mUK_nNNoOXL23UUMujBg1SpvsJgmxJCXFowSMM9d_7_bkbPGtZ055yZTTP5Fn6UnEmsa6flxxl96Q=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Jam Baxter", s: "YouTube", ai: "UCxyG5eBCQI3jeOc8Z_6djDw", i: "https://yt3.ggpht.com/YKs0f9wFE2QTxtU8Y2VN-T5FbLv-0t-OLNBioS3XKjt3pep6qqFDXvVlGiwJEhQAmQG6QkjiiQKWENrUEWA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Jehst", s: "YouTube", ai: "UCp-zxi4IwvjTuqkPgZxki0w", i: "https://yt3.ggpht.com/fz-1Uqp_Ruhszy7rzW8fPbn9OuYWbq2VoBYZ8LMYWI8qXuNFjQHMzmR7rj8FYx2f-MK360SRVrPw7-c-bsk=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Jme", s: "YouTube", ai: "UCFj0VFnY7FbhyHlbOpxQv-g", i: "https://yt3.ggpht.com/pWqhNMXesRUgwM4t-7Dt0ew66jWQYVB3Q3RSLhiRlKG3a4C3sFaJm4Ay-RgB3wYWc_-Su1NMbXhhuqls1w=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "L Dot Man", s: "SoundCloud", ai: "190074010", i: "https://i1.sndcdn.com/avatars-000190919215-nsn9lj-t500x500.jpg" },
            { a: "LDZ", s: "YouTube", ai: "UCVKdRqi6dXFVk6bzqcfpu1A", i: "https://yt3.ggpht.com/BL3-0YPu1T6t8UjS5j6Xpz4r_K9GbBSqPGhu6h-BZo1F8FiK_u6HX-x4-DPV06OavvdHN0XyRbhuPLKyZg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "LEE SCOTT", s: "SoundCloud", ai: "14566456", i: "https://i1.sndcdn.com/avatars-000247032735-7e70pz-t500x500.jpg" },
            { a: "Lunaville Resident", s: "YouTube", ai: "UC6i5F53BwRSvgIGIS-2IZtA", i: "https://yt3.ggpht.com/a-/AN66SAxnoFhXka9eO8eBWYNiv8tbUtL9Wxo0k5Hm_Q=s800-mo-c-c0xffffffff-rj-k-no" },            { a: "Mountjarvis", s: "YouTube", ai: "UC9N_PMgNvGXKY3PE1tgqDSw", i: "https://yt3.ggpht.com/a-/AN66SAyp_7eI0lcp8dl9vcZOCCCG-MtqTRd9TcWA2Q=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Ocean Wisdom", s: "YouTube", ai: "UCE3L9cxGQLZ2oBEP69naJtg", i: "https://yt3.ggpht.com/6FwEXlG2xMX9hZu-JilTtLaHpqjYAQxZ3xFatVWMJJt3AIfpeBebtkLn3lK6r6Exa_hzUiiJKqb6EeJX=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Onoe Caponoe", s: "YouTube", ai: "UCKzwMMqCMNF1zQnYSBlHZxg", i: "https://yt3.ggpht.com/wrYd9O6BoMyXLXOIe0Ki4vN8MdNPMX7wDIP6JB4jLZMCkYOLYVqphtCR6jWcsfJvWetT-BnJIYAW0zIl=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "P-Money", s: "YouTube", ai: "UCUxW6LD8IJ4pzuoKAKX3MJA", i: "https://yt3.ggpht.com/BU7Lwe2PmWV2Qf6OnehAQST5mOmdh9UNxbiKmU8sEyQuxvg_N7X69-7RjUife8ppS8YhX52PGf0UmeLWbg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Shotty Horroh", s: "YouTube", ai: "UCgH8z9JRtFpJ0-QJ8Gmn9Xw", i: "https://yt3.ggpht.com/EJVJ6E1iG29OPfwFhqBY9Yaz7zlJemE_B6DQpeXsBTla2ipaRHNUKNTKd49wrM66wp31BNvXXQlqDJK2=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Slowthai", s: "YouTube", ai: "UCnolvzHG37C_6k8ghz1bC9w", i: "https://yt3.ggpht.com/oU95fSoUF2IqkSjie4ZNbQ0w0_GKTrrIX06d2ABwFitrU-7YHAoI4FhwDT-XHvCGlKdYtlEPv43sd0qcUQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Stinkin Slumrok", s: "YouTube", ai: "UCnUFOjzHOXVZNBy6g7EjwhA", i: "https://yt3.ggpht.com/pXCg6eulS-0kF9UnhEQ69Zr_sKn_ZlTRVoZmXXP36DgNVpSsX019n6Mz-X0Bg8QeQYQYBc9ASQczfCKe=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Verb T", s: "YouTube", ai: "UCR8Sg2caWY8UGlHNOgGQZeA", i: "https://yt3.ggpht.com/UU-yS_3PYUOT6zgPpL95a6fxiFeeWWHpyy7UY4aFTj3rrtA99rB1BqE-0CRCiDyEw1PVCz5NT41-xeen=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Wiley", s: "YouTube", ai: "UCbqpQaop91HIa08tTGzhOjQ", i: "https://yt3.ggpht.com/VH2S3Eb4ezEkxIdelAANs76p_hv8FQWJn2ahBlPDT69EYXOr5B_O12T7BX4OQ4M17hDx5QueZpWA8A0EjQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Wretch 32", s: "YouTube", ai: "UCXZwsjh089km2RF9oyuxe3g", i: "https://yt3.ggpht.com/a-/AN66SAxAbS3x9Z1JxcsLyKzjW63_DpKTvUu1dHFXKg=s800-mo-c-c0xffffffff-rj-k-no" },

          ]
        },
        {
          name: 'House',
          items: [
            { a: "808 State", s: "YouTube", ai: "UCIyGjRHvtCqUglkPZVEWUuA", i: "https://yt3.ggpht.com/xhtuo-erwzMjIoTIsPMDfPn3jbrWjBW3URWvHqEtA5Hg1pd8QXiUUzAdKcYi8T5tiYWROnl1yJK7oFjZug=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "AfrojackVEVO", s: "YouTube", ai: "UChuZAo1RKL85gev3Eal9_zg", i: "https://yt3.ggpht.com/a-/ACSszfGfyoRunjqutnvqOvN-xieYm4zfymiABKWvoQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Avicii", s: "YouTube", ai: "UCuACQmW04T3v9Mz_1_suFYw", i: "https://yt3.ggpht.com/ZKTBxH52EhTWZokBr7O5UKfxqJWYvj5v69C7rVOLMFq054YF1WiiMPLbXmwCUpJF9LNZ8AwE3s_y7wVjXg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "deadmau5", s: "YouTube", ai: "UCL44WZGVf-BU5N0ymCXrpBg", i: "https://yt3.ggpht.com/OpJDXBXK7ADy29EtEXQBn8GfAKmGnb9AeakfyqXQT9aQkOZyVZhbI2fi9-eydvwqdkSzEKsYFpLqtK8E-w=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Diplo", s: "YouTube", ai: "UCXAX3AtRPPdesKYSS8FKayg", i: "https://yt3.ggpht.com/xaol-air_v6baxLuW0Glr7C-yCKYVJEwF3y8Ow1MM0piNdw-gYwAUUcNe_2TPBjipK_gxzJF2ayZLCteZY0=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Flume", s: "YouTube", ai: "UCXAhoI7XO2kafTMjocm0jCg", i: "https://yt3.ggpht.com/a-/ACSszfFgnLjXEi5s6ApvFLpmrRe4stZvRBMmtCtMSQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Frankie Knuckles", s: "YouTube", ai: "UCGpjbS7U2isnZVGns3J9Ckg", i: "https://yt3.ggpht.com/AdcshOophS0nG2yWS-JfqppVDFAMBT10j8bypQAHYesbOGktxhsnVx2gaIUS3-cvJKLTwMz9aR-znPbt=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Kym Mazelle", s: "YouTube", ai: "UCpLr8sXJqc-BmUjC1vMqnsA", i: "https://yt3.ggpht.com/GmnVUnVN9FJXKs90cxBgZrWN3dFB7wXmRwWCOIOfBM0_HyI2azt32OK6MX5CwOPESr3QIpcgKWqhCMSX=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Larry Heard", s: "YouTube", ai: "UCLhLg21tnAtPKvcFODfRAXQ", i: "https://yt3.ggpht.com/A25Zk05a5MEqHU4HUUDy7maaJd6Zw8Vh2CQkvaP-7PZ9erQrrSHlG3BKKhzDSq3hmgiAWvgPijQzDEdJaQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Phuture Noize", s: "YouTube", ai: "UCASv7c0bxfN9QF7z7lVsUZA", i: "https://yt3.ggpht.com/4WuTMQ9HtaVzONb2X21o6883M4zA_C1gSq16Co-ykuupabMvvtFwlT-XsFULYoUFYKguj5r_npCZpvuFPQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Tiësto", s: "YouTube", ai: "UC8VSaPhuiHkjobAgNpRqLIA", i: "https://yt3.ggpht.com/nZeRTqyvHYm7vwEruQV4DCBLifuLCE6c19WhgvNX50D3RutLbn9LBts4g6P8-IAhi541e1nqy77wXuJNmg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Zedd", s: "YouTube", ai: "UCGVGIqHPzwLhZg8KQNVaRbA", i: "https://yt3.ggpht.com/N0lFRjOCk7Y1-YNdXYdHq-aajwp1nIk8_FkQUIZp9KTDozK8oZq451LTp2EuHfPzhZz-jgxZbVEq83rfUw=s800-mo-c-c0xffffffff-rj-k-no" },
          ]
        },
        {
          name: 'Jazz',
          items: [
            { a: "Art Blakey", s: "YouTube", ai: "UCMki-b0zfAQiMQ0nbsrIuBQ", i: "https://yt3.ggpht.com/Y2NZDfUVhCj0WSFDFCFOJAbSHMAXIvnfy7gD6hh5IRYK-9X5JsB7ol1-_5jNV2kzRTTkYIE8cbdmS1qIO-o=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Benny Goodman", s: "YouTube", ai: "UC23m4qWjf07Yx0SwKqQr3VQ", i: "https://yt3.ggpht.com/7Wi_xk1iZz3SNtaZNUO17Kv16nSKfD5IOep9ZULPpZYC30gn_ZCDiThmGCiMJsiPz0aGxYrSCvy3PDrRxZ0=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Bill Evans", s: "YouTube", ai: "UCriB97bZopXsBHVYOQEIIZg", i: "https://yt3.ggpht.com/Nvjp4dfgT0irUAxgLE3iumk3-551VtDezXC8eIaeZ-BWdCaI-FsM-fDs1Dcby_CMAmbT-uqLCBZuPMFOwUg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Billie Holiday", s: "YouTube", ai: "UCW-raws5Iq2xLADkLcEoVaA", i: "https://yt3.ggpht.com/vW3_j-paP4Q5Y3ZyLNHnFHtkrpkzdUfJetc_g1Xx98PYFW6_3xEEP67W0xNSURKYvyHPfGa1HbMBqacNRDA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Bud Powell", s: "YouTube", ai: "UCsyeGJfR7t0QBrNUl7c36gw", i: "https://yt3.ggpht.com/ik-TnO5ioMG05z5y2M5jQoVoAaF5O0j1o8u3BYAuUKuY2ZkQrV9qqXarMQDET_VzYk0QFiTVPFeQGLg7=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Buddy Rich", s: "YouTube", ai: "UCX4J3GV1DSyEpFvjGCoSNqQ", i: "https://yt3.ggpht.com/2QPrNB4Q6TabniFdqnQs0MXTsuc7D_CRfZ-W1SACbqNzYkDw-hH_5JTAZfT6MjRn4-m5dTg48C-lMHgQFA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Cannonball Adderley", s: "YouTube", ai: "UCRQLvDfTNOFUgst4GpnyDvA", i: "https://yt3.ggpht.com/MeoPcIDDDlxv4_dFJ80ahjqqeNv1yDL5JDL54qi3YzcgZI3EUmOQiE_K1fetagDqzn2LwYI11EyYpqBT=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Chet Baker", s: "YouTube", ai: "UCVNfRXuaWVILL9giCEg0rQg", i: "https://yt3.ggpht.com/wIo8j3g0xBZ5PyEkFvAa6jdEYdoNeDEhPyLnCQh-ot7q5_Ux1IPrxuNUKa49_ruB664KbwbEWCferzEjmw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Charles Mingus", s: "YouTube", ai: "UCXSaOCck3oVxhB4W_4Ca3MQ", i: "https://yt3.ggpht.com/_TjA-mQ4QF9JYk79w0lRiiCSR8IHB6mKXjdmA3gXJLhh1pEjGadvf7LWE9QoR8IHQQ-R3rgr4KvUTM8zJg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Charlie Parker", s: "YouTube", ai: "UCPFmyRluI7yvEdbHCrecUng", i: "https://yt3.ggpht.com/Xe5V_19qfUL8EPghLEFXv2ndAAk1h6E6Fcj9gDFNP54l0xM7f9QIiWXumKu-_pOYhcJwMd4nL6NZll3sNw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Chick Corea", s: "YouTube", ai: "UC7Syqiz3THx07IfHPlgroRA", i: "https://yt3.ggpht.com/t3j4ekucA3mFFEo6K1Vl_JoTcSxAmxg2BsBY3IG7K_hU-BZUUrRVzu1bB_ONyJXsHKDfPDXqlfrY_piUCQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Clifford Brown", s: "YouTube", ai: "UCQFCMVgOtWDn5Vd3Nt1SRfQ", i: "https://yt3.ggpht.com/Wx24fxNEGH4kAErQ-P7p4RYXDPgF2ByTRoVZXZtGpaBWu1ShLMvT385NOwHqykluMS3Hu5hlPmCcJTWN7w=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Coleman Hawkins", s: "YouTube", ai: "UCaqOj5uQl-733nBtBpEEGBw", i: "https://yt3.ggpht.com/FDyYDyIrE3_hrM0THz3k-cWzxIadxJKZYoHmaWiWTroo4IEjojz6_kWkj19wZSn8rnBfOBNZGAzzPsX2QA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Count Basie", s: "YouTube", ai: "UC2C5LKX_qE6BzyMehXA0ClA", i: "https://yt3.ggpht.com/yUnkmKhWUcSMVPbe48ottqbbUIC9SialtpgCyXnJsX5qB1Y3IzyjFNI1lXQOrLpY9e2PXwAdylrQwxCdxDE=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Dave Brubeck", s: "YouTube", ai: "UCMBevFAp40kVlvIcOvzv5Bw", i: "https://yt3.ggpht.com/2JtDRr6LYVH5x5RSPWltl3eYaz9MSuq7vPey_yQM84cIG9X3DJq6p4TiFpsGcDPsllTCv7CqsEfr78wqXQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Dexter Gordon", s: "YouTube", ai: "UCnH1LrQs42YLOQnpdoUYvdA", i: "https://yt3.ggpht.com/bNCX6ZTqJOBgWWDnYgTCNpuOs-gEsswZEMj16IngMNzXMsmeV_UMhbZJPc0OapOpgHlusXelANEcy_FaBg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Django Reinhardt", s: "YouTube", ai: "UCDvzmvEF-ReWkWb8B_jL-qQ", i: "https://yt3.ggpht.com/hWvkLlF9QpHmT2mCNGB7VwTQNNzNT8SpLXG1679t139uR7EZ9A3K4Z3JwdSj7WD14uqPA5COKTR4iOl8EQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Diana Krall", s: "YouTube", ai: "UCHOHY0V0VKiEW0Yw7DR4xQw", i: "https://yt3.ggpht.com/hP_LRT_BYWXLk0mEh6aSHW3NT9qRSN0jTB98Ogbgg-qfhjX8fgnen3Y6mo724KFlEP_87ABgZrlOaX_WaA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Dizzy Gillespie", s: "YouTube", ai: "UCw_wrXoRl-ionafhIWtcRMA", i: "https://yt3.ggpht.com/9GrMXgKfJs-uKdXDnRtSDJSTuoagO9mXNjSm3Hpyff5hkJUmwKT0rp-YhZ5CKanN0AYfAwjYjJCq0Tgy=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Duke Ellington", s: "YouTube", ai: "UCvwUPRgFawNNBdQg497gHJw", i: "https://yt3.ggpht.com/wPas5cmp2tJ5WKk_KTucd-8R6f8_PIWsX7hQc_49Y_SBISW0DduBIVSl6UINAzAO9HvbKxkSvDwNVysaRg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Earl Hines", s: "YouTube", ai: "UCBeBkWYRI18waVif35oF77g", i: "https://yt3.ggpht.com/OUezxdHA7uX00kN-DQ-wrWkH_MvJjiUcdGyij34PJxwaaDTxDMChWCooND_9EEdvTR1pjFP3DJ9JHZRnQg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Ella Fitzgerald", s: "YouTube", ai: "UCYKZTGPwv7ddoMC8Jgi2VYw", i: "https://yt3.ggpht.com/B_0itykEN3p9tuhJ7owLWrSYZGQ6cfFT24tnnC8R4IVLWv7PO8mq7ZNgKzsmCoRD99unQHYDDx1w9PvyFw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Frank Sinatra", s: "YouTube", ai: "UC1zsfp3OD8qWQ0HfLbz2TXg", i: "https://yt3.ggpht.com/yPrWhumR2Nrh81MXbuXtZ6jNw8JFg_O3tA_hGYV7Rctp3i56B1T9tJ77ogI6uH_o1qyS_mSvuj-E7repDQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Freddie Hubbard", s: "YouTube", ai: "UCK-G8P50pf0b1t6dd1ZiCFg", i: "https://yt3.ggpht.com/URcr4QSj3AQRv3oF2ayGVmIyZ7q96DSUvS_TyzdGPUzyZiZrUc61638wdnPuMMF0ERIn3TsVb5On99FZgg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Herbie Hancock", s: "YouTube", ai: "UCq_O_14tCKbx9U9uUT_LEPA", i: "https://yt3.ggpht.com/RtqbbpXsYF1ItwacikVKOX0YvdT6psQiyDdisLVHslLfd_Yx2E6SUntq69jhD6OU9cL1IjnKHEwNv6KsRg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "John Coltrane", s: "YouTube", ai: "UCH4T2kv7rr9qnuP0DOXLxMA", i: "https://yt3.ggpht.com/LFnbZKBj1XW_HxCOTJ1B92Z7HWN7obC7LVnej2Lqw25orWsQqq4cd0_Iid-gjSUY0jpTIzXO2VNMtEFhJA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Jelly Roll Morton", s: "YouTube", ai: "UCiKpyur6AJCOyJx_ZoINNiw", i: "https://yt3.ggpht.com/6GpnB3ylAXpgdUzzPU5VZq_L34Kf5YiarVmEyA10NVY9F1VGsGRhvYne33Okhk7EEdtwVSHFWFfBmCN1wQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Keith Jarrett", s: "YouTube", ai: "UCm3Mj3cmimqk3qMPK_UJHvw", i: "https://yt3.ggpht.com/NybbCRhQQw57IeVKKjWit0imfAD1eL1Exw-dh7UiBf4mfg0ueg4dzXkxv_w5OJuGdUijeW7Pn79HZ8qWRA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Lester Young", s: "YouTube", ai: "UCwAovW7EG-ibqPOd7JNH2tA", i: "https://yt3.ggpht.com/tKc-iIaf_a03bX_TvMpTlu6X9xr0opO3lIsZcKf4ahdF3lJtkqzzjN3E91eReh8FYuF2K0WzzC6H65wJy0Q=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Lionel Hampton", s: "YouTube", ai: "UCpfWWFslWSapwL_q16AboSg", i: "https://yt3.ggpht.com/JZ8hv1upiOUbpLpxo59oJ-urz1yKefVcH8H8q2TrBB2l31Q_jtx_sHqpGce1iPc66UOfQwbRBpkftFUzcQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Louis Daniel Armstrong", s: "YouTube", ai: "UCCDaSui4C9VFMpeRlKEOHDA", i: "https://yt3.ggpht.com/2SCoP3A6bNCxI3fv1jqMKCNzrY8Kr9zJFQf8mNzktZQj0gCt8uXZ0fZzF61eNsuXUuYR5FuXeYc3JHinww=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Miles Davis", s: "YouTube", ai: "UCIev2PktTH5mI-QlGmbUkiw", i: "https://yt3.ggpht.com/AbVZaa33IS4S6jPUUu9sBk4NKbmkmyAK77awkxr1NfInUJDCNfZPs_fWI84TabJkYV47FBVAiA9_MRnCTQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Max Roach", s: "YouTube", ai: "UCxTSDTDzVM4MW42oD9iTPqQ", i: "https://yt3.ggpht.com/osz_eN10SkWic03ouP8NO6dCCVe7fpTMUxld-xcn6BygSOrQ2nAP08NeP2xogicH_WC62nYImzJ0P88UXw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Nat King Cole", s: "YouTube", ai: "UCirPLQsYtHWBmalEbX1LcAA", i: "https://yt3.ggpht.com/ODYoHhYr1yle-2_80YtTua5iTshbXoLpmhjspq5elZoPtWCA6erE0mmKIMM2ly_ZJRoIOmBC1r0cz9ql=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Sarah Vaughan", s: "YouTube", ai: "UCVIvDAZP_e1e3bKzKFaPfig", i: "https://yt3.ggpht.com/pODA1sWRTE3eivtAe5KGOjPEb3Dxg6Yb6V5tZcSYpuhFBRaUU5c1pc5BLwhjhUKchfeb5vgNo-cvp-Kdqw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Sonny Rollins", s: "YouTube", ai: "UCqwmTSEZTKX_BmxlmDSOzGQ", i: "https://yt3.ggpht.com/WFSTJmIxQwaxy8ijQbfQISGnj-FL8ui9P8EmbuNdMeTNYNhZWQKbGKjP4p_Ikv9Vf5ar0MKtUkQ5N9vn=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Stan Getz", s: "YouTube", ai: "UCITWDrIiWv0Y-zj8xrvoY-Q", i: "https://yt3.ggpht.com/irzETTO-mPGSb6D0vO3L3S8mZWhS7KvOGGqWVZMRAYzkCu6uplLtNKaeF8CMrZtPk3KnbmPh65xpr5E4GA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Horace Silver", s: "YouTube", ai: "UC834B7DbQ6WZzigm4UCwuKg", i: "https://yt3.ggpht.com/lBT8UjmlooJB6nhZSk_iEM7dpcq4I-czgOOs9HNkZh4TKLTzLd7X1kIct0G9ORq6x4wOR-t6wK2yPmQS=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Ornette Coleman", s: "YouTube", ai: "UCMD_nRrrkezVzMumc1hBuwQ", i: "https://yt3.ggpht.com/hqURBkmw1-6kMA8v5DqiLrns-g6q1ASsNHJqS3V1F_oiN5z812t59tH8gkuJtzREDPgVJidRuDlVdT9GNg0=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Sun Ra", s: "YouTube", ai: "UChUQgC_KvNmK6Na3Zt9o-0Q", i: "https://yt3.ggpht.com/8ou2ztYi15QEE1-JG_BQBxBlEoTeHWnxxG6LCm-V--IrRx0jkOIJnzPJtcQxGNVlqnM1er-5LCIjgyEatQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Shawn Lane", s: "YouTube", ai: "UCgEs5iiDgtwtKYI8-zEHfxA", i: "https://yt3.ggpht.com/ZUbSb_tk6TGmfbfIF1u3jK4S03rPbQcth2d6weWEzLsDSmuD3MsIxQ9DxMdqRqNHmkVcuCWTIF5XlPyrTg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Oscar Peterson Trio", s: "YouTube", ai: "UCL2bbNhLtFzY9u6z6xXTMVg", i: "https://yt3.ggpht.com/XILrNcoL2c4KjG67j8Uj-hqC88xuf1NWfx9oJRo9yqcrs_g3WS2okf1zN4Dvf89k45POU8WOOoUwDQgi=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Thelonious Monk", s: "YouTube", ai: "UCyCL_gVNVoWZTjkw-KnuIDg", i: "https://yt3.ggpht.com/Gb0GLMA2FPi_b4kxzZ5cS1PaLohvoboX3q_kDjafVI-7DbigrUFL_T3eg39Hpog2fLNHKKagW6-krumOrw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Wayne Shorter", s: "YouTube", ai: "UC3X4afoYfFCLWw1LTfeLCqA", i: "https://yt3.ggpht.com/rrpzA0Cd_JzulSJGrU9Drs_6UFNEuM540MMu9WBgabXq0cCZBCJV8qxX0HTj8jFiOSEpe7A8qiG8xEiMag=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Wes Montgomery", s: "YouTube", ai: "UCYs8ep9Xe3RQc3Oy4BWKNAw", i: "https://yt3.ggpht.com/gbuSwsSdjrXlutiRHMUHgVC3QAce5Xzh4APwJ8U7TIP1kWcWWgCzDjyEK7iNWWfhWdMhqoHsKoTxp82yTYk=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Wynton Marsalis", s: "YouTube", ai: "UCzWGLXcvQlN_VMWJes9VYyw", i: "https://yt3.ggpht.com/kzd3yRTN6JaBoOeDIxHX58vMe9wWAGttK3w6wLrIC6XSX-6ZDQMyOapvmz_V6_UwPC47B0jXh6xcovlbtQ=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The J.B.'s ", s: "YouTube", ai: "UCH0J4AgVPF-krK6K9Ykav3g", i: "https://yt3.ggpht.com/Hp18LseT2yfjBevdURk8-mfZfq2QElIXOOdSUliVuLJYl0uS1mpAHh4z17Gh73xCYRfizMmIhydsEIh3=s800-mo-c-c0xffffffff-rj-k-no" },
          ]
        },
        {
          name: 'Rock',
          items: [
            { a: "AD/DC", s: "YouTube", ai: "UCmPuJ2BltKsGE2966jLgCnw", i: "https://yt3.ggpht.com/a-/ACSszfHpdA9T-J0S2RMoUvL37wl2SwRFcbF8A9zYfg=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Beatles", s: "YouTube", ai: "UC2XdaAVUannpujzv32jcouQ", i: "https://yt3.ggpht.com/gdTyVeIdiOczsrtBrmHCxMZUEsIySP6BpQlyeSX0LIJyJ83pLAPfwjJywPO26ZBiNNHySoRlOpOvzswV=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Elvis Presely", s: "YouTube", ai: "UChgxarBUCnPJV871-46bJ2g", i: "https://yt3.ggpht.com/1StP4iAp_r8Q4waKlCeH8z4WhsUb_SNccrif_K2RT81xG6FNmCbKAXJUDps-lc1xhMqCuxwRoDZVRmoecqU=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Guns N' Roses", s: "YouTube", ai: "UCSLbbBoUqpin6BE34whSOvA", i: "https://yt3.ggpht.com/S4_JLRIDlrHghB8L_sP2jheceusmJzWpNB4ny5-5y-IydbnxjgIazl2R0CyW2SK2l6oVNx-Kpns3nLBb=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Led Zeppelin", s: "YouTube", ai: "UCYtap7ujIPaxTS2iCDoMi3g", i: "https://yt3.ggpht.com/OCDhdpQrM_iPQhGfECSk0k7oUgi5yH1yfhl0_KwJSJhkNH-9n1ppL2lxJyIfO_ExH1y9lNSWRGGW4ffzmA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Linkin Park", s: "YouTube", ai: "UCxgN32UVVztKAQd2HkXzBtw", i: "https://yt3.ggpht.com/rfiAR456-U1d3-fREicMGs4MRilSkBsMzQaR2SdYVi5UEUaOkZ7ZuXignKGoosZ-THFmezHiaiDRL1elCA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Metallica", s: "YouTube", ai: "UCGexNm_Kw4rdQjLxmpb2EKw", i: "https://yt3.ggpht.com/OK8GWIespm2piEg-hSXMBf35O99v9X8JQVortW_sdtCzeC4dX3F004lWt2iX_jAKrc3TYDQCyfsWa2rEeA=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Nirvana", s: "YouTube", ai: "UCrPe3hLA51968GwxHSZ1llw", i: "https://yt3.ggpht.com/6WUuIFTBnvgPsp_KduShfNWhe9DrdAwlxFupVKLjOj8eT857-MpFt1wFTRFoHw9WgFcqWOkc1kAxvTpL=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Pink Floyd", s: "YouTube", ai: "UCO6LS_5W7vqG9mALDNzSFug", i: "https://yt3.ggpht.com/dYnVXw9DV25YWv6D0RIz4ykwbmxHiFMbZEtOTETo138XcEdBqCrTQSM9RoVQnxfVNvDZu5Ss9f-G8ysYnyI=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Queen", s: "YouTube", ai: "UCEPMVbUzImPl4p8k4LkGevA", i: "https://yt3.ggpht.com/NApYslAVit5f9MJxsJ_GPg3TGjtND2FgKqb8eQ_pqpO-8Zx3pLdO4uU4ZX9l3acRFgSahBteHLrU-9JrCHE=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Rage Against the Machine", s: "YouTube", ai: "UCg4nBubbzhYXjudOxPi9V7w", i: "https://yt3.ggpht.com/61S9hOjD4uf6F1u1ZSWKsHfIxTeeZWWJN3o5Najbako1w9HTWPLh3kiYK23fKf6aJZkZOGhdQIKqFdMsrw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Rolling Stones", s: "YouTube", ai: "UCNYhhkQqeFLUc-YEDcLpSYQ", i: "https://yt3.ggpht.com/vsjSbER8CTUBKtIN51QgLta48xfDAdeACP3Ai6CbN6EN4iD60XZUP6d0vfdIXWjoRLuHGafqikGMJqZdECc=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "Status Quo", s: "YouTube", ai: "UC2oCil_CLZt9xh3FE73H8rg", i: "https://yt3.ggpht.com/WLfnZDxMRx3A5MAK7WjdKrAfBOVyuh5qxACP0VRTH8ZCdW-GhloDMq_OGE9-BNVyphDL-hLT_8RN9-cesw=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "System Of A Down", s: "YouTube", ai: "UCDJftX2zx_UT_QSnBGIF96w", i: "https://yt3.ggpht.com/tDd7dCDigf3yca9JoLH1thUIWY3EcAUH9EzJS1MTcXq518-Qq_xMPthZbUuOUHAEgQn6gm76FAjhsEVf5g=s800-mo-c-c0xffffffff-rj-k-no" },
            { a: "The Who", s: "YouTube", ai: "UCpxn_sVrLQWNGFK1eulpYgw", i: "https://yt3.ggpht.com/L-DZ5QvIZtdWhjAfHsxaS9PqKKwpQYonGglKqJVo6jc55W0dNwSeW5bSrtNgHKzT8tYJwidgkhzUI-ygnHk=s800-mo-c-c0xffffffff-rj-k-no" }
          ]
        }
      ]
    }
  }
}
</script>

<style>
.bg-rp{
  background-repeat: repeat;
}
</style>
